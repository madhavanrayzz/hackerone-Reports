Top reports from Pornhub program at HackerOne:

1. [[phpobject in cookie] Remote shell/command execution](https://hackerone.com/reports/141956) to Pornhub - 607 upvotes, $20000
2. [Deserialization of untrusted data at https://www.redtube.com/media/hls?s=data](https://hackerone.com/reports/1312641) to Pornhub - 271 upvotes, $10000
3. [idor allows you to delete photos and album from a gallery](https://hackerone.com/reports/380410) to Pornhub - 266 upvotes, $1500
4. [IDOR allows any user to edit others videos](https://hackerone.com/reports/681473) to Pornhub - 248 upvotes, $1500
5. [Publicly exposed SVN repository, ht.pornhub.com](https://hackerone.com/reports/72243) to Pornhub - 211 upvotes, $10000
6. [Blind SQL injection and making any profile comments from any users to disappear using "like" function (2 in 1 issues)](https://hackerone.com/reports/363815) to Pornhub - 211 upvotes, $0
7. [Blind SQL injection in Hall of Fap](https://hackerone.com/reports/295841) to Pornhub - 179 upvotes, $0
8. [CRITICAL ISSUE : Leak of all accounts mail login md5 pass and more](https://hackerone.com/reports/514488) to Pornhub - 157 upvotes, $0
9. [Multiple endpoints are vulnerable to XML External Entity injection (XXE) ](https://hackerone.com/reports/72272) to Pornhub - 138 upvotes, $2500
10. [View storyboard of private video @ ht.pornhub.com](https://hackerone.com/reports/138703) to Pornhub - 130 upvotes, $750
11. [vulnerabilitie](https://hackerone.com/reports/137723) to Pornhub - 127 upvotes, $0
12. [XSS via JavaScript evaluation of an attacker controlled resource at www.pornhub.com](https://hackerone.com/reports/944518) to Pornhub - 109 upvotes, $250
13. [[RCE] Unserialize to XXE - file disclosure on ams.upload.pornhub.com](https://hackerone.com/reports/142562) to Pornhub - 90 upvotes, $0
14. [xss](https://hackerone.com/reports/306554) to Pornhub - 84 upvotes, $0
15. [Reflect XSS on Mobile Search page ](https://hackerone.com/reports/380246) to Pornhub - 79 upvotes, $250
16. [Unsecured DB instance](https://hackerone.com/reports/189192) to Pornhub - 73 upvotes, $5000
17. [Blind XSS in redtube administering site my.reflected.net](https://hackerone.com/reports/603941) to Pornhub - 72 upvotes, $1000
18. [Reflected XSS on www.pornhub.com and www.pornhubpremium.com](https://hackerone.com/reports/1354161) to Pornhub - 71 upvotes, $750
19. [SSRF and local file disclosure by video upload on https://www.redtube.com/upload](https://hackerone.com/reports/570537) to Pornhub - 61 upvotes, $500
20. [[idor] Unauthorized Read access to all the private posts(Including Photos,Videos,Gifs)](https://hackerone.com/reports/148764) to Pornhub - 58 upvotes, $1500
21. [SSRF and local file disclosure by video upload on https://www.tube8.com/](https://hackerone.com/reports/574133) to Pornhub - 53 upvotes, $500
22. [Wordpress Content injection ](https://hackerone.com/reports/202949) to Pornhub - 48 upvotes, $1500
23. [Stored XSS in photo comment functionality](https://hackerone.com/reports/172227) to Pornhub - 44 upvotes, $0
24. [Stored XSS (client-side, using cookie poisoning) on the pornhubpremium.com](https://hackerone.com/reports/311948) to Pornhub - 40 upvotes, $0
25. [RCE Possible Via Video Manager Export using @ character in Video Title](https://hackerone.com/reports/146593) to Pornhub - 38 upvotes, $500
26. [Unsecured Elasticsearch Instance](https://hackerone.com/reports/267161) to Pornhub - 36 upvotes, $3500
27. [Stored XSS on the https://www.redtube.com/users/[profile]/collections](https://hackerone.com/reports/380204) to Pornhub - 36 upvotes, $0
28. [[stored xss, pornhub.com] stream post function](https://hackerone.com/reports/138075) to Pornhub - 35 upvotes, $1500
29. [SSRF and local file disclosure by video upload on http://www.youporn.com/](https://hackerone.com/reports/574134) to Pornhub - 35 upvotes, $500
30. [Stored XSS in galleries - https://www.redtube.com/gallery/[id] path](https://hackerone.com/reports/380207) to Pornhub - 35 upvotes, $0
31. [IDOR - disclosure of private videos - /api_android_v3/getUserVideos](https://hackerone.com/reports/186279) to Pornhub - 32 upvotes, $1500
32. [[IDOR] post to anyone even if their stream is restricted to friends only](https://hackerone.com/reports/137954) to Pornhub - 31 upvotes, $0
33. [Time Based SQL-inject in post-parametr login[username] [domain - youporn.com]](https://hackerone.com/reports/203935) to Pornhub - 30 upvotes, $2500
34. [Weak user aunthentication on mobile application - I just broken userKey secret password](https://hackerone.com/reports/138101) to Pornhub - 29 upvotes, $5000
35. [[xss, pornhub.com] /, multiple parameters](https://hackerone.com/reports/138319) to Pornhub - 28 upvotes, $250
36. [I am because bug](https://hackerone.com/reports/226188) to Pornhub - 27 upvotes, $0
37. [XSS reflected on [https://www.youporn.com]](https://hackerone.com/reports/478530) to Pornhub - 25 upvotes, $150
38. [[IDOR] Deleting other users comment](https://hackerone.com/reports/138243) to Pornhub - 25 upvotes, $0
39. [Self-XSS to Good-XSS - pornhub.com](https://hackerone.com/reports/761904) to Pornhub - 25 upvotes, $0
40. [Possibility to insert stored XSS inside \<img\> tag](https://hackerone.com/reports/267643) to Pornhub - 22 upvotes, $0
41. [Single User DOS by Poisoning Cookie via Get Parameter](https://hackerone.com/reports/416966) to Pornhub - 22 upvotes, $0
42. [XSS vulnerability using GIF tags](https://hackerone.com/reports/191674) to Pornhub - 19 upvotes, $0
43. [Add a video to favourite list of any user [via YouPorn API / FrontEnd]](https://hackerone.com/reports/203047) to Pornhub - 19 upvotes, $0
44. [Unsecured Grafana instance](https://hackerone.com/reports/167585) to Pornhub - 18 upvotes, $750
45. [Unsecured Kibana/Elasticsearch instance](https://hackerone.com/reports/188482) to Pornhub - 18 upvotes, $750
46. [Account takeover via Pornhub Oauth](https://hackerone.com/reports/192648) to Pornhub - 17 upvotes, $1000
47. [Partial disclosure of Private Videos through data-mediabook attribute information leak](https://hackerone.com/reports/228495) to Pornhub - 17 upvotes, $0
48. [IDOR - Access to private video thumbnails even if video requires password authentication](https://hackerone.com/reports/197114) to Pornhub - 17 upvotes, $0
49. [(Pornhub & Youporn & Brazzers ANDROID APP) : Upload Malicious APK / Overrite Existing APK  / Android BackOffice Access ](https://hackerone.com/reports/142352) to Pornhub - 16 upvotes, $1500
50. [Mobile Reflect XSS / CSRF at Advertisement Section on Search page](https://hackerone.com/reports/379705) to Pornhub - 15 upvotes, $200
51. [Find whether a video has been favourited or not, for any user [via YouPorn Mobile API]](https://hackerone.com/reports/203042) to Pornhub - 15 upvotes, $0
52. [XSS on pornhubselect.com](https://hackerone.com/reports/222556) to Pornhub - 15 upvotes, $0
53. [Private Photo Disclosure - /user/stream_photo_attach?load=album&id= endpoint](https://hackerone.com/reports/141868) to Pornhub - 14 upvotes, $0
54. [DOM-based XSS on youporn.com (main page)](https://hackerone.com/reports/221883) to Pornhub - 14 upvotes, $0
55. [Stored XSS in the any user profile using website link](https://hackerone.com/reports/242213) to Pornhub - 14 upvotes, $0
56. [Account hijack via deleted PH account](https://hackerone.com/reports/201940) to Pornhub - 13 upvotes, $1000
57. [Race Condition Vulnerability On Pornhubpremium.com](https://hackerone.com/reports/183624) to Pornhub - 13 upvotes, $520
58. [Mixed Reflected-Stored XSS on pornhub.com (without user interaction) in the playlist playing section](https://hackerone.com/reports/222506) to Pornhub - 13 upvotes, $0
59. [Public Facing Barracuda Login](https://hackerone.com/reports/119918) to Pornhub - 12 upvotes, $250
60. [Blind Stored XSS against Pornhub employees using Amateur Model Program](https://hackerone.com/reports/216379) to Pornhub - 12 upvotes, $0
61. [XSS Vulnerability at https://www.pornhubpremium.com/premium_signup? URL endpoint ](https://hackerone.com/reports/202548) to Pornhub - 11 upvotes, $250
62. [youporn email notification enable/disable  and newsletter ](https://hackerone.com/reports/205506) to Pornhub - 11 upvotes, $0
63. [[ssrf] libav vulnerable during conversion of uploaded videos](https://hackerone.com/reports/111269) to Pornhub - 10 upvotes, $1500
64. [Debug.log file Exposed to Public \Full Path Disclosure\](https://hackerone.com/reports/202939) to Pornhub - 10 upvotes, $0
65. [Reflected XSS in login redirection module](https://hackerone.com/reports/216806) to Pornhub - 10 upvotes, $0
66. [http://ht.pornhub.com/ stored XSS in widget stylesheet](https://hackerone.com/reports/207792) to Pornhub - 10 upvotes, $0
67. [Unprotected Memcache Installation running](https://hackerone.com/reports/119871) to Pornhub - 9 upvotes, $2500
68. [Disclosure of private photos/albums - http://www.pornhub.com/album/show_image_box](https://hackerone.com/reports/167582) to Pornhub - 9 upvotes, $750
69. [XSS via login cookie](https://hackerone.com/reports/206737) to Pornhub - 9 upvotes, $100
70. [Reflected XSS by way of jQuery function](https://hackerone.com/reports/141493) to Pornhub - 9 upvotes, $50
71. [Stored XSS on the http://ht.pornhub.com/widgets/](https://hackerone.com/reports/186613) to Pornhub - 9 upvotes, $0
72. [CSRF Full Account Takeover - https://redtube.com/settings](https://hackerone.com/reports/388531) to Pornhub - 9 upvotes, $0
73. [pornhub.com/user/welcome/basicinfo nickname field is vulnerable on xss](https://hackerone.com/reports/241198) to Pornhub - 8 upvotes, $750
74. [ Same-Origin Method Execution bug in plupload.flash.swf on /insights](https://hackerone.com/reports/138226) to Pornhub - 8 upvotes, $150
75. [CSV Macro injection in Video Manager (CEMI)](https://hackerone.com/reports/137850) to Pornhub - 8 upvotes, $100
76. [[crossdomain.xml] Dangerous Flash Cross-Domain Policy](https://hackerone.com/reports/105655) to Pornhub - 8 upvotes, $50
77. [[Android API] SQL injection ( errortoken.json )](https://hackerone.com/reports/204050) to Pornhub - 8 upvotes, $0
78. [Unauthenticated access to Content Management System - www1.pornhubpremium.com](https://hackerone.com/reports/72735) to Pornhub - 7 upvotes, $5000
79. [SSRF & XSS (W3 Total Cache)](https://hackerone.com/reports/138721) to Pornhub - 7 upvotes, $1000
80. [[idor] Profile Admin can pin any other user's post on his stream wall](https://hackerone.com/reports/138852) to Pornhub - 7 upvotes, $750
81. [PornIQ Reflected Cross-Site Scripting](https://hackerone.com/reports/105486) to Pornhub - 7 upvotes, $250
82. [Private videos can be added to our playlists](https://hackerone.com/reports/246819) to Pornhub - 7 upvotes, $0
83. [Reflected XSS in Meta Tag](https://hackerone.com/reports/203974) to Pornhub - 6 upvotes, $250
84. [Reflected cross-site scripting (XSS) vulnerability in pornhub.com allows attackers to inject arbitrary web script or HTML.](https://hackerone.com/reports/182132) to Pornhub - 5 upvotes, $200
85. [Cross Site Scripting – Album Page](https://hackerone.com/reports/82929) to Pornhub - 5 upvotes, $50
86. [Reflected Cross-Site Scripting on French subdomain](https://hackerone.com/reports/101108) to Pornhub - 4 upvotes, $250
87. [Cross Site Scripting - On Mouse Over, Blog page](https://hackerone.com/reports/100552) to Pornhub - 4 upvotes, $250
88. [[xss, pornhub.com] /user/[username], multiple parameters](https://hackerone.com/reports/100550) to Pornhub - 4 upvotes, $250
89. [[reflected xss, pornhub.com] /blog, any](https://hackerone.com/reports/83566) to Pornhub - 4 upvotes, $100
90. [HTTP Track/Trace Method Enabled](https://hackerone.com/reports/119860) to Pornhub - 4 upvotes, $50
91. [XSS Reflected incategories*p](https://hackerone.com/reports/138046) to Pornhub - 3 upvotes, $250
92. [XSS ReflectedGET /*embed_player*?](https://hackerone.com/reports/138045) to Pornhub - 3 upvotes, $250
93. [[xss] pornhubpremium.com, /redeem?code= URL endpoint ](https://hackerone.com/reports/202536) to Pornhub - 3 upvotes, $250
94. [Reflected XSS on ht.pornhub.com - /export/GetPreview](https://hackerone.com/reports/216469) to Pornhub - 1 upvotes, $0
