Top reports from Gratipay program at HackerOne:

1. [Saying goodbye to HackerOne and Gratipay.](https://hackerone.com/reports/286728) to Gratipay - 94 upvotes, $0
2. [Reflected XSS - gratipay.com](https://hackerone.com/reports/262852) to Gratipay - 36 upvotes, $0
3. [i am The bug](https://hackerone.com/reports/284807) to Gratipay - 21 upvotes, $0
4. [configure a redirect URI for Facebook OAuth](https://hackerone.com/reports/140432) to Gratipay - 16 upvotes, $10
5. [Sub Domain Takeover](https://hackerone.com/reports/221133) to Gratipay - 16 upvotes, $0
6. [fix bug in username restriction](https://hackerone.com/reports/128121) to Gratipay - 14 upvotes, $0
7. [SQL TEST](https://hackerone.com/reports/248037) to Gratipay - 14 upvotes, $0
8. [Application-level DoS on image's "size" parameter.](https://hackerone.com/reports/247700) to Gratipay - 14 upvotes, $0
9. [change bank account numbers](https://hackerone.com/reports/90805) to Gratipay - 13 upvotes, $0
10. [don't leak Server version for assets.gratipay.com](https://hackerone.com/reports/149710) to Gratipay - 12 upvotes, $0
11. [User Supplied links on profile page is not validated and redirected via gratipay.](https://hackerone.com/reports/151831) to Gratipay - 12 upvotes, $0
12. [Limit email address length](https://hackerone.com/reports/127995) to Gratipay - 11 upvotes, $0
13. [Content length restriction bypass can lead to DOS by reading large files on gip.rocks](https://hackerone.com/reports/203388) to Gratipay - 11 upvotes, $0
14. [Reflected SQL Execution](https://hackerone.com/reports/284811) to Gratipay - 11 upvotes, $0
15. [HTTP trace method is enabled on aspen.io](https://hackerone.com/reports/203409) to Gratipay - 10 upvotes, $0
16. [Gratipay rails secret token (secret_key_base) publicly exposed in GitHub](https://hackerone.com/reports/262620) to Gratipay - 10 upvotes, $0
17. [Sub Domain Take over](https://hackerone.com/reports/111078) to Gratipay - 9 upvotes, $0
18. [upgrade Aspen on inside.gratipay.com to pick up CR injection fix](https://hackerone.com/reports/143139) to Gratipay - 8 upvotes, $40
19. [Email Forgery through Mandrillapp SPF](https://hackerone.com/reports/117097) to Gratipay - 8 upvotes, $10
20. [Stored XSS On Statement](https://hackerone.com/reports/84740) to Gratipay - 8 upvotes, $0
21. [Host Header Injection/Redirection Attack](https://hackerone.com/reports/157465) to Gratipay - 8 upvotes, $0
22. [Session Fixation At Logout /Session Misconfiguration](https://hackerone.com/reports/193556) to Gratipay - 8 upvotes, $0
23. [Inadequate/dangerous jQuery behavior](https://hackerone.com/reports/211149) to Gratipay - 8 upvotes, $0
24. [protect against tabnabbing in statement](https://hackerone.com/reports/109161) to Gratipay - 8 upvotes, $0
25. [CSV injection in gratipay.com via payment history export feature.](https://hackerone.com/reports/219323) to Gratipay - 8 upvotes, $0
26. [Avoid "resend verification email" confusion](https://hackerone.com/reports/156542) to Gratipay - 7 upvotes, $1
27. [No Valid SPF Records.](https://hackerone.com/reports/116973) to Gratipay - 6 upvotes, $10
28. [suppress version in Server header on gratipay.com or grtp.co](https://hackerone.com/reports/123742) to Gratipay - 6 upvotes, $1
29. [Incomplete or No Cache-control and Pragma HTTP Header Set](https://hackerone.com/reports/185833) to Gratipay - 6 upvotes, $0
30. [Transferring incorrect data to the http://gip.rocks/v1 endpoint with correct Content-Type leads to local paths disclosure through the error message](https://hackerone.com/reports/219601) to Gratipay - 6 upvotes, $0
31. [[gratipay.com] CRLF Injection](https://hackerone.com/reports/79552) to Gratipay - 5 upvotes, $40
32. [don't serve hidden files from Nginx](https://hackerone.com/reports/120026) to Gratipay - 5 upvotes, $1
33. [Content Spoofing/Text Injection ](https://hackerone.com/reports/154921) to Gratipay - 5 upvotes, $1
34. [weak ssl cipher suites](https://hackerone.com/reports/76303) to Gratipay - 5 upvotes, $0
35. [Cross Site Scripting In Profile Statement ](https://hackerone.com/reports/162120) to Gratipay - 5 upvotes, $0
36. [Gratipay uses the random module's cryptographically insecure PRNG.](https://hackerone.com/reports/190373) to Gratipay - 5 upvotes, $0
37. [Username can be used to trick the victim on the name of www.gratipay.com](https://hackerone.com/reports/163904) to Gratipay - 5 upvotes, $0
38. [Content-Length restriction bypass to heap overflow in gip.rocks.](https://hackerone.com/reports/214449) to Gratipay - 5 upvotes, $0
39. [HTTP trace method is enabled on gip.rocks](https://hackerone.com/reports/203384) to Gratipay - 5 upvotes, $0
40. [Harden resend throttling](https://hackerone.com/reports/108645) to Gratipay - 5 upvotes, $0
41. [Prevent content spoofing on /~username/emails/verify.html](https://hackerone.com/reports/117187) to Gratipay - 5 upvotes, $0
42. [clickjacking on https://gratipay.com/on/npm/[text]](https://hackerone.com/reports/267189) to Gratipay - 5 upvotes, $0
43. [Missing Certificate Authority Authorization rule](https://hackerone.com/reports/261706) to Gratipay - 5 upvotes, $0
44. [HTTP trace method is enabled](https://hackerone.com/reports/109054) to Gratipay - 4 upvotes, $5
45. [SPF/DKIM/DMARC for aspen.io](https://hackerone.com/reports/117159) to Gratipay - 4 upvotes, $0
46. [Hijacking user session by forcing the use of  invalid HTTPs Certificate on images.gratipay.com](https://hackerone.com/reports/124976) to Gratipay - 4 upvotes, $0
47. [prevent null bytes in email field](https://hackerone.com/reports/150917) to Gratipay - 4 upvotes, $0
48. [don't allow directory browsing on grtp.co](https://hackerone.com/reports/151295) to Gratipay - 4 upvotes, $0
49. [strengthen Diffie-Hellman (DH) key exchange parameters in grtp.co](https://hackerone.com/reports/117458) to Gratipay - 4 upvotes, $0
50. [limit HTTP methods on other domains](https://hackerone.com/reports/117142) to Gratipay - 4 upvotes, $0
51. [auto-logout after 20 minutes](https://hackerone.com/reports/123897) to Gratipay - 4 upvotes, $0
52. [Reset Link Issue](https://hackerone.com/reports/161918) to Gratipay - 4 upvotes, $0
53. [CSRF csrftoken in cookies](https://hackerone.com/reports/174228) to Gratipay - 4 upvotes, $0
54. [Cookie HttpOnly Flag Not Set ](https://hackerone.com/reports/190194) to Gratipay - 4 upvotes, $0
55. [Secure Pages Include Mixed Content](https://hackerone.com/reports/185835) to Gratipay - 4 upvotes, $0
56. [nginx version disclosure on downloads.gratipay.com](https://hackerone.com/reports/157507) to Gratipay - 4 upvotes, $0
57. [CSP Policy Bypass and javascript execution](https://hackerone.com/reports/241192) to Gratipay - 4 upvotes, $0
58. [Mail spaming](https://hackerone.com/reports/87531) to Gratipay - 3 upvotes, $20
59. [Send email asynchronously](https://hackerone.com/reports/128856) to Gratipay - 3 upvotes, $10
60. [stop serving grtp.co over HTTP](https://hackerone.com/reports/117330) to Gratipay - 3 upvotes, $1
61. [Authentication errors in server side validaton of E-MAIL](https://hackerone.com/reports/80883) to Gratipay - 3 upvotes, $0
62. [The POODLE attack (SSLv3 supported) for https://grtp.co/](https://hackerone.com/reports/116360) to Gratipay - 3 upvotes, $0
63. [implement a cross-domain policy for Adobe products](https://hackerone.com/reports/90778) to Gratipay - 3 upvotes, $0
64. [The contribution save option seem to be vulnerable to CSRF](https://hackerone.com/reports/151827) to Gratipay - 3 upvotes, $0
65. [XSS Via Method injection](https://hackerone.com/reports/161621) to Gratipay - 3 upvotes, $0
66. [Certificate signed using SHA-1](https://hackerone.com/reports/190015) to Gratipay - 3 upvotes, $0
67. [Username Restriction is not applied for reserved folders](https://hackerone.com/reports/163949) to Gratipay - 3 upvotes, $0
68. [This is a test report](https://hackerone.com/reports/151165) to Gratipay - 3 upvotes, $0
69. [Login csrf.](https://hackerone.com/reports/117195) to Gratipay - 3 upvotes, $0
70. [Show hide privacy giving receiving on my website ](https://hackerone.com/reports/262088) to Gratipay - 3 upvotes, $0
71. [Adding Used Primary Email Address to attacker account and Account takeover](https://hackerone.com/reports/273647) to Gratipay - 3 upvotes, $0
72. [bring grtp.co up to A grade on SSLLabs](https://hackerone.com/reports/131065) to Gratipay - 2 upvotes, $1
73. [limit number of images in statement](https://hackerone.com/reports/117739) to Gratipay - 2 upvotes, $1
74. [SPF/DKIM/DMARC for grtp.co](https://hackerone.com/reports/117149) to Gratipay - 2 upvotes, $0
75. [Self XSS Protection not used , I can trick users to insert JavaScript](https://hackerone.com/reports/76307) to Gratipay - 2 upvotes, $0
76. [DKIM records not present, Email Hijacking is possible](https://hackerone.com/reports/84287) to Gratipay - 2 upvotes, $0
77. [Possible SQL injection on "Jump to twitter"](https://hackerone.com/reports/81701) to Gratipay - 2 upvotes, $0
78. [Vulnerable to clickjacking](https://hackerone.com/reports/123782) to Gratipay - 2 upvotes, $0
79. [don't store CSRF tokens in cookies](https://hackerone.com/reports/140377) to Gratipay - 2 upvotes, $0
80. [csrf_token cookie don't have the flag "HttpOnly"](https://hackerone.com/reports/123900) to Gratipay - 2 upvotes, $0
81. [User Enumeration](https://hackerone.com/reports/192986) to Gratipay - 2 upvotes, $0
82. [Content type incorrectly stated](https://hackerone.com/reports/190964) to Gratipay - 2 upvotes, $0
83. [URL Given leading to end users ending up in malicious sites](https://hackerone.com/reports/209821) to Gratipay - 2 upvotes, $0
84. [Unauthorized access to the slack channel via inside.gratipay.com/appendices/chat](https://hackerone.com/reports/226648) to Gratipay - 2 upvotes, $0
85. [X-Content-Type Header Missing For aspen.io](https://hackerone.com/reports/118033) to Gratipay - 2 upvotes, $0
86. [CSP "script-src" includes "unsafe-inline" in https://gratipay.com](https://hackerone.com/reports/231086) to Gratipay - 2 upvotes, $0
87. [SPF Protection not used, I can hijack your email server](https://hackerone.com/reports/93157) to Gratipay - 2 upvotes, $0
88. [set Expires header](https://hackerone.com/reports/145207) to Gratipay - 2 upvotes, $0
89. [don't leak Server version for assets.gratipay.com](https://hackerone.com/reports/151302) to Gratipay - 2 upvotes, $0
90. [[gratipay.com] Cross Site Tracing](https://hackerone.com/reports/152834) to Gratipay - 2 upvotes, $0
91. [Host Header poisoning on gratipay.com](https://hackerone.com/reports/158482) to Gratipay - 2 upvotes, $0
92. [After removing app from facebook app session not expiring.](https://hackerone.com/reports/129209) to Gratipay - 2 upvotes, $0
93. [xss ](https://hackerone.com/reports/262005) to Gratipay - 2 upvotes, $0
94. [Missing Certificate Authority Authorization rule](https://hackerone.com/reports/260928) to Gratipay - 2 upvotes, $0
95. [set Pragma header](https://hackerone.com/reports/145206) to Gratipay - 2 upvotes, $0
96. [Bypassing X-frame options ](https://hackerone.com/reports/283951) to Gratipay - 2 upvotes, $0
97. [DMARC is misconfigured for grtp.co](https://hackerone.com/reports/117325) to Gratipay - 1 upvotes, $10
98. [grtp.co is vulnerable to http-vuln-cve2011-3192](https://hackerone.com/reports/112687) to Gratipay - 1 upvotes, $0
99. [SPF DNS Record ](https://hackerone.com/reports/115275) to Gratipay - 1 upvotes, $0
100. [Cookie Does Not Contain The "secure" Attribute](https://hackerone.com/reports/123849) to Gratipay - 1 upvotes, $0
101. [An adversary can harvest email address for spamming.](https://hackerone.com/reports/128035) to Gratipay - 1 upvotes, $0
102. [Getting Error Message and in use python version 2.7 is exposed.](https://hackerone.com/reports/128041) to Gratipay - 1 upvotes, $0
103. [prevent content spoofing on /search](https://hackerone.com/reports/115284) to Gratipay - 1 upvotes, $0
104. [text injection in website title](https://hackerone.com/reports/128764) to Gratipay - 1 upvotes, $0
105. [don't expose path of Python ](https://hackerone.com/reports/138659) to Gratipay - 1 upvotes, $0
106. [don't leak server version of grtp.co in error pages](https://hackerone.com/reports/136720) to Gratipay - 1 upvotes, $0
107. [Username .. (double dot) should be restricted or handled carefully](https://hackerone.com/reports/152477) to Gratipay - 1 upvotes, $0
108. [Cookie:HttpOnly Flag not set](https://hackerone.com/reports/157563) to Gratipay - 1 upvotes, $0
109. [POODLE SSLv3.0](https://hackerone.com/reports/219499) to Gratipay - 1 upvotes, $0
110. [Gratipay Website CSP "script-scr" includes "unsafe-inline"](https://hackerone.com/reports/231510) to Gratipay - 1 upvotes, $0
111. [Email Spoofing](https://hackerone.com/reports/240987) to Gratipay - 1 upvotes, $0
112. [CSP Policy Bypass and javascript execution Still Not Fixed](https://hackerone.com/reports/241341) to Gratipay - 1 upvotes, $0
113. [Possible user session hijack by invalid HTTPS certificate on inside.gratipay.com domain](https://hackerone.com/reports/241892) to Gratipay - 1 upvotes, $0
114. [Possible User Session Hijack using Invalid HTTPS certificate on inside.gratipay.com domain](https://hackerone.com/reports/242622) to Gratipay - 1 upvotes, $0
115. [Insecure Transportation Security Protocol Supported (TLS 1.0)](https://hackerone.com/reports/163812) to Gratipay - 1 upvotes, $0
116. [prevent content spoofing on /~username/emails/verify.html](https://hackerone.com/reports/126010) to Gratipay - 1 upvotes, $0
117. [Lack of CSRF token validation at server side](https://hackerone.com/reports/163815) to Gratipay - 1 upvotes, $0
118. [PHP 5.4.45 is Outdated and Full of Preformance Interupting Arbitrary Code Execution Bugs](https://hackerone.com/reports/131452) to Gratipay - 1 upvotes, $0
119. [400 Bad Request [Use a third-party provider to sign in or create an account on Gratipay]](https://hackerone.com/reports/267212) to Gratipay - 1 upvotes, $0
120. [Information Disclosure on inside.gratipay.com](https://hackerone.com/reports/267213) to Gratipay - 1 upvotes, $0
121. [XSS found In Your Web](https://hackerone.com/reports/164922) to Gratipay - 1 upvotes, $0
122. [nginx SPDY heap buffer overflow for https://grtp.co/](https://hackerone.com/reports/116352) to Gratipay - 0 upvotes, $0
123. [UDP port 5060 (SIP) Open](https://hackerone.com/reports/116774) to Gratipay - 0 upvotes, $0
124. [proxy port 7000 and shell port 514 not filtered](https://hackerone.com/reports/116618) to Gratipay - 0 upvotes, $0
125. [server calendar and server status available to public](https://hackerone.com/reports/116621) to Gratipay - 0 upvotes, $0
126. [self cross site scripting](https://hackerone.com/reports/245762) to Gratipay - 0 upvotes, $0
127. [SSl Weak Ciphers](https://hackerone.com/reports/244070) to Gratipay - 0 upvotes, $0
128. [x-xss protection header is not set in response header](https://hackerone.com/reports/162336) to Gratipay - 0 upvotes, $0
129. [Usernames ending in .json are not restricted](https://hackerone.com/reports/161935) to Gratipay - 0 upvotes, $0
130. [Sub domain take over in gratipay.com](https://hackerone.com/reports/257331) to Gratipay - 0 upvotes, $0
131. [Directory Listing on grtp.co](https://hackerone.com/reports/109116) to Gratipay - 0 upvotes, $0
132. [Submit a non valid syntax email](https://hackerone.com/reports/131053) to Gratipay - 0 upvotes, $0
133. [Markdown parsing issue enables insertion of malicious tags](https://hackerone.com/reports/116512) to Gratipay - 0 upvotes, $0
134. [Possible Blind SQL injection | Language choice in presentation](https://hackerone.com/reports/131047) to Gratipay - 0 upvotes, $0
135. [prevent %2f spoofed URLs in profile statement](https://hackerone.com/reports/128910) to Gratipay - 0 upvotes, $0
136. [Broken link for stale DNS entry may be leveraged for Phishing, Misinformation, Serving Malware](https://hackerone.com/reports/279351) to Gratipay - 0 upvotes, $0
