Top reports from Paragon Initiative Enterprises program at HackerOne:

1. [BAD Code ! ](https://hackerone.com/reports/180074) to Paragon Initiative Enterprises - 483 upvotes, $0
2. [DMARC  Not found for paragonie.com   URGENT](https://hackerone.com/reports/179828) to Paragon Initiative Enterprises - 136 upvotes, $0
3. [Subdomain Takeover](https://hackerone.com/reports/180393) to Paragon Initiative Enterprises - 67 upvotes, $0
4. [I am because bug](https://hackerone.com/reports/226094) to Paragon Initiative Enterprises - 38 upvotes, $0
5. [ssl info shown ](https://hackerone.com/reports/149369) to Paragon Initiative Enterprises - 31 upvotes, $0
6. [[Critical] billion dollars issue](https://hackerone.com/reports/244836) to Paragon Initiative Enterprises - 29 upvotes, $0
7. [Stored Cross-Site-Scripting in CMS Airship's  authors profiles](https://hackerone.com/reports/148741) to Paragon Initiative Enterprises - 23 upvotes, $50
8. [Email Spoof](https://hackerone.com/reports/115452) to Paragon Initiative Enterprises - 16 upvotes, $0
9. [Site support SNI But Browser can't](https://hackerone.com/reports/149442) to Paragon Initiative Enterprises - 15 upvotes, $0
10. [Content-type sniffing leads to stored XSS in CMS Airship on Internet Explorer ](https://hackerone.com/reports/151231) to Paragon Initiative Enterprises - 15 upvotes, $0
11. [Spf ](https://hackerone.com/reports/116927) to Paragon Initiative Enterprises - 14 upvotes, $0
12. [Stored XSS using  SVG ](https://hackerone.com/reports/148853) to Paragon Initiative Enterprises - 12 upvotes, $50
13. [Paragonie Airship Admin CSRF on Extensions Pages](https://hackerone.com/reports/243094) to Paragon Initiative Enterprises - 11 upvotes, $100
14. [Full directory path listing](https://hackerone.com/reports/230098) to Paragon Initiative Enterprises - 10 upvotes, $0
15. [Improper access control lead  To delete anyone comment](https://hackerone.com/reports/273805) to Paragon Initiative Enterprises - 8 upvotes, $100
16. [Directory Disclose,Email Disclose Zendmail vulnerability](https://hackerone.com/reports/228112) to Paragon Initiative Enterprises - 8 upvotes, $50
17. [Stored XSS in comments](https://hackerone.com/reports/148751) to Paragon Initiative Enterprises - 6 upvotes, $25
18. [[Airship CMS] Local File Inclusion - RST Parser](https://hackerone.com/reports/179034) to Paragon Initiative Enterprises - 6 upvotes, $0
19. [Incorrect detection of onion URLs](https://hackerone.com/reports/181210) to Paragon Initiative Enterprises - 5 upvotes, $50
20. [Session Management](https://hackerone.com/reports/145300) to Paragon Initiative Enterprises - 5 upvotes, $0
21. [Issue with password reset functionality [Minor]](https://hackerone.com/reports/149027) to Paragon Initiative Enterprises - 5 upvotes, $0
22. [Incomplete fix for #181225 (target=_blank vulnerability)](https://hackerone.com/reports/226104) to Paragon Initiative Enterprises - 5 upvotes, $0
23. [Open-redirect on paragonie.com](https://hackerone.com/reports/113112) to Paragon Initiative Enterprises - 4 upvotes, $50
24. [Cross-site-Scripting](https://hackerone.com/reports/226203) to Paragon Initiative Enterprises - 4 upvotes, $50
25. [Invited user to a Author profile can remove the owner of that Author](https://hackerone.com/reports/274541) to Paragon Initiative Enterprises - 4 upvotes, $50
26. [CSRF  AT SUBSCRIBE TO LIST ](https://hackerone.com/reports/115323) to Paragon Initiative Enterprises - 4 upvotes, $0
27. [Broken Authentication & Session Management - Failure to Invalidate Session on all other browsers at Password change](https://hackerone.com/reports/226712) to Paragon Initiative Enterprises - 4 upvotes, $0
28. [Airship: Persistent XSS via Comment](https://hackerone.com/reports/301973) to Paragon Initiative Enterprises - 4 upvotes, $0
29. [CSRF token does not valided during blog comment](https://hackerone.com/reports/273998) to Paragon Initiative Enterprises - 3 upvotes, $25
30. [User enumeration  via Password reset page [Minor]](https://hackerone.com/reports/148911) to Paragon Initiative Enterprises - 3 upvotes, $0
31. [Email Spoofing With Your Website's Email](https://hackerone.com/reports/163156) to Paragon Initiative Enterprises - 3 upvotes, $0
32. [SMTP server allows anonymous relay from internal addresses to internal addresses](https://hackerone.com/reports/144385) to Paragon Initiative Enterprises - 3 upvotes, $0
33. [Github repo's wiki publicly editable](https://hackerone.com/reports/461429) to Paragon Initiative Enterprises - 3 upvotes, $0
34. [Recaptcha Secret key Leaked](https://hackerone.com/reports/1416665) to Paragon Initiative Enterprises - 3 upvotes, $0
35. [Missing rel=noopener noreferrer in target=_blank links (Phishing attack)](https://hackerone.com/reports/181225) to Paragon Initiative Enterprises - 2 upvotes, $50
36. [Information Disclosure in Error Page](https://hackerone.com/reports/115219) to Paragon Initiative Enterprises - 2 upvotes, $0
37. [Missing SPF](https://hackerone.com/reports/115294) to Paragon Initiative Enterprises - 2 upvotes, $0
38. [Email spoofing in security@paragonie.com](https://hackerone.com/reports/148763) to Paragon Initiative Enterprises - 2 upvotes, $0
39. [Nginx Version Disclosure On Forbidden Page](https://hackerone.com/reports/148768) to Paragon Initiative Enterprises - 2 upvotes, $0
40. [Full path disclosure when CSRF validation failed ](https://hackerone.com/reports/148890) to Paragon Initiative Enterprises - 2 upvotes, $0
41. [Session Management Issue CMS Airship](https://hackerone.com/reports/148914) to Paragon Initiative Enterprises - 2 upvotes, $0
42. [[URGENT] Password reset emails are sent in clear-text (without encryption)](https://hackerone.com/reports/149028) to Paragon Initiative Enterprises - 2 upvotes, $0
43. [Full Path Disclosure by removing CSRF token](https://hackerone.com/reports/150018) to Paragon Initiative Enterprises - 2 upvotes, $0
44. [Not clearing hex-decoded variable after usage in Authentication](https://hackerone.com/reports/168293) to Paragon Initiative Enterprises - 2 upvotes, $0
45. [directory information disclose](https://hackerone.com/reports/226212) to Paragon Initiative Enterprises - 2 upvotes, $0
46. [Full Path Disclousure on https://airship.paragonie.com](https://hackerone.com/reports/226514) to Paragon Initiative Enterprises - 2 upvotes, $0
47. [no session logout after changing the password  in https://bridge.cspr.ng/](https://hackerone.com/reports/226518) to Paragon Initiative Enterprises - 2 upvotes, $0
48. [Improper validation of Email ](https://hackerone.com/reports/226334) to Paragon Initiative Enterprises - 2 upvotes, $0
49. [Your Application Have Cacheable SSL Pages](https://hackerone.com/reports/115296) to Paragon Initiative Enterprises - 2 upvotes, $0
50. [Github wikis are editable by anyone https://github.com/paragonie/password_lock/wiki](https://hackerone.com/reports/661977) to Paragon Initiative Enterprises - 2 upvotes, $0
51. [Full Path Disclosure](https://hackerone.com/reports/115337) to Paragon Initiative Enterprises - 1 upvotes, $50
52. [Vunerability : spf](https://hackerone.com/reports/130990) to Paragon Initiative Enterprises - 1 upvotes, $0
53. [DNSsec not configured](https://hackerone.com/reports/115246) to Paragon Initiative Enterprises - 1 upvotes, $0
54. [The Anti-CSRF Library fails to restrict token to a particular IP address when being behind a reverse-proxy/WAF](https://hackerone.com/reports/134894) to Paragon Initiative Enterprises - 1 upvotes, $0
55. [Missing SPF for paragonie.com](https://hackerone.com/reports/115315) to Paragon Initiative Enterprises - 1 upvotes, $0
56. [SSL certificate public key less than 2048 bit](https://hackerone.com/reports/115271) to Paragon Initiative Enterprises - 1 upvotes, $0
57. [Email Authentication Bypass](https://hackerone.com/reports/135283) to Paragon Initiative Enterprises - 1 upvotes, $0
58. [Full path disclosure vulnerability on paragonie.com](https://hackerone.com/reports/145260) to Paragon Initiative Enterprises - 1 upvotes, $0
59. [Email Authentication bypass Vulnerability](https://hackerone.com/reports/115245) to Paragon Initiative Enterprises - 1 upvotes, $0
60. [Cross-domain AJAX request](https://hackerone.com/reports/113339) to Paragon Initiative Enterprises - 1 upvotes, $0
61. [Email spoofing](https://hackerone.com/reports/115232) to Paragon Initiative Enterprises - 1 upvotes, $0
62. [Missing SPF records for paragonie.com](https://hackerone.com/reports/115250) to Paragon Initiative Enterprises - 1 upvotes, $0
63. [file full path discloser.](https://hackerone.com/reports/116057) to Paragon Initiative Enterprises - 1 upvotes, $0
64. [Missing SPF for paragonie.com](https://hackerone.com/reports/115390) to Paragon Initiative Enterprises - 1 upvotes, $0
65. [Blind SQL INJ](https://hackerone.com/reports/115304) to Paragon Initiative Enterprises - 1 upvotes, $0
66. [Airship doesn't reject weak passwords](https://hackerone.com/reports/148903) to Paragon Initiative Enterprises - 1 upvotes, $0
67. [Using plain git protocol (vulnerable to MITM)](https://hackerone.com/reports/181214) to Paragon Initiative Enterprises - 1 upvotes, $0
68. [There is an vulnerability in https://bridge.cspr.ng where an attacker can users directory](https://hackerone.com/reports/226505) to Paragon Initiative Enterprises - 1 upvotes, $0
69. [Missing SPF for https://paragonie.com/](https://hackerone.com/reports/115214) to Paragon Initiative Enterprises - 0 upvotes, $0
70. [Missing GIT tag/commit verification in Docker](https://hackerone.com/reports/181212) to Paragon Initiative Enterprises - 0 upvotes, $0
71. [Not using Binary::safe* functions for substr/strlen function](https://hackerone.com/reports/181315) to Paragon Initiative Enterprises - 0 upvotes, $0
72. [Non-secure requests are not automatically upgraded to HTTPS](https://hackerone.com/reports/241950) to Paragon Initiative Enterprises - 0 upvotes, $0
73. [Full Path Disclosure in airship.paragonie.com '/cabins/'](https://hackerone.com/reports/226343) to Paragon Initiative Enterprises - 0 upvotes, $0
74. [Full Path Disclosure in password lock](https://hackerone.com/reports/115422) to Paragon Initiative Enterprises - 0 upvotes, $0
75. [Full Path Disclosure In EasyDB](https://hackerone.com/reports/119494) to Paragon Initiative Enterprises - 0 upvotes, $0
