Top reports from Yahoo! program at HackerOne:

1. [Local File Include on marketing-dam.yahoo.com](https://hackerone.com/reports/7779) to Yahoo! - 19 upvotes, $2500
2. [Header injection on rmaitrack.ads.vip.bf1.yahoo.com](https://hackerone.com/reports/6322) to Yahoo! - 16 upvotes, $1000
3. [Cross-site scripting on the main page of flickr by tagging a user.](https://hackerone.com/reports/916) to Yahoo! - 14 upvotes, $2173
4. [XSS Yahoo Messenger Via Calendar.Yahoo.Com ](https://hackerone.com/reports/914) to Yahoo! - 14 upvotes, $677
5. [Store XSS Flicker main page](https://hackerone.com/reports/940) to Yahoo! - 12 upvotes, $1960
6. [REMOTE CODE EXECUTION/LOCAL FILE INCLUSION/XSPA/SSRF, view-source:http://sb*.geo.sp1.yahoo.com/, 4/6/14, #SpringClean](https://hackerone.com/reports/6674) to Yahoo! - 11 upvotes, $3000
7. [Loadbalancer + URI XSS #3](https://hackerone.com/reports/9703) to Yahoo! - 10 upvotes, $0
8. [readble .htaccess + Source Code Disclosure  (+ .SVN repository)](https://hackerone.com/reports/7813) to Yahoo! - 8 upvotes, $250
9. [HK.Yahoo.Net Remote Command Execution](https://hackerone.com/reports/2127) to Yahoo! - 7 upvotes, $1276
10. [Bypass of the Clickjacking protection on Flickr using data URL in iframes](https://hackerone.com/reports/7264) to Yahoo! - 7 upvotes, $250
11. [Information Disclosure ](https://hackerone.com/reports/1091) to Yahoo! - 7 upvotes, $0
12. [From Unrestricted File Upload to Remote Command Execution](https://hackerone.com/reports/4836) to Yahoo! - 6 upvotes, $800
13. [HTML Injection on flickr screename using IOS App](https://hackerone.com/reports/1483) to Yahoo! - 6 upvotes, $800
14. [Directory Traversal ](https://hackerone.com/reports/1092) to Yahoo! - 6 upvotes, $0
15. [SQLi on http://sports.yahoo.com/nfl/draft](https://hackerone.com/reports/1538) to Yahoo! - 5 upvotes, $3705
16. [Java Applet Execution On Y! Messenger](https://hackerone.com/reports/933) to Yahoo! - 5 upvotes, $0
17. [Local file inclusion ](https://hackerone.com/reports/1675) to Yahoo! - 4 upvotes, $1390
18. [Significant Information Disclosure/Load balancer access, http://extprodweb11.cc.gq1.yahoo.com/, 4/8/14, #SpringClean](https://hackerone.com/reports/6194) to Yahoo! - 4 upvotes, $500
19. [reflected XSS, http://extprodweb11.cc.gq1.yahoo.com/, 4/8/14, #SpringClean](https://hackerone.com/reports/6195) to Yahoo! - 4 upvotes, $300
20. [ads.yahoo.com Unvalidate open url redirection](https://hackerone.com/reports/7731) to Yahoo! - 4 upvotes, $0
21. [Security.allowDomain("*") in SWFs on img.autos.yahoo.com allows data theft from Yahoo Mail (and others)](https://hackerone.com/reports/1171) to Yahoo! - 3 upvotes, $2500
22. [SQL Injection ON HK.Promotion](https://hackerone.com/reports/3039) to Yahoo! - 3 upvotes, $1000
23. [Flickr: Invitations disclosure (resend feature)](https://hackerone.com/reports/1533) to Yahoo! - 3 upvotes, $750
24. [https://caldav.calendar.yahoo.com/ - XSS (STORED) ](https://hackerone.com/reports/8281) to Yahoo! - 3 upvotes, $500
25. [invite1.us2.msg.vip.bf1.yahoo.com/ - CSRF/email disclosure](https://hackerone.com/reports/7608) to Yahoo! - 3 upvotes, $400
26. [XSS Vulnerability (my.yahoo.com)](https://hackerone.com/reports/4256) to Yahoo! - 3 upvotes, $250
27. [http://conf.member.yahoo.com configuration file disclosure](https://hackerone.com/reports/2598) to Yahoo! - 3 upvotes, $100
28. [Default /docs folder of PHPBB3 installation on gamesnet.yahoo.com](https://hackerone.com/reports/17506) to Yahoo! - 3 upvotes, $50
29. [ClickJacking on http://au.launch.yahoo.com](https://hackerone.com/reports/1229) to Yahoo! - 3 upvotes, $0
30. [Yahoo YQL Injection? ](https://hackerone.com/reports/1407) to Yahoo! - 3 upvotes, $0
31. [In Fantasy Sports iOS app, signup page is requested over HTTP](https://hackerone.com/reports/2101) to Yahoo! - 3 upvotes, $0
32. [caesary.yahoo.net Blind Sql Injection](https://hackerone.com/reports/21899) to Yahoo! - 3 upvotes, $0
33. [Stored Cross Site Scripting Vulnerability in Yahoo Mail](https://hackerone.com/reports/4277) to Yahoo! - 3 upvotes, $0
34. [XSS in my yahoo](https://hackerone.com/reports/1203) to Yahoo! - 2 upvotes, $800
35. [information disclosure (LOAD BALANCER + URI XSS)](https://hackerone.com/reports/8284) to Yahoo! - 2 upvotes, $300
36. [XSS in Yahoo! Web Analytics](https://hackerone.com/reports/5442) to Yahoo! - 2 upvotes, $100
37. [Vulnerability found, XSS (Cross site Scripting)](https://hackerone.com/reports/1258) to Yahoo! - 2 upvotes, $0
38. [HTML Code Injection ](https://hackerone.com/reports/1376) to Yahoo! - 2 upvotes, $0
39. [Open Redirect via Request-URI](https://hackerone.com/reports/15298) to Yahoo! - 2 upvotes, $0
40. [XSS using yql and developers console proxy](https://hackerone.com/reports/1011) to Yahoo! - 2 upvotes, $0
41. [Bypass of anti-SSRF defenses in YahooCacheSystem (affecting at least YQL and Pipes)](https://hackerone.com/reports/1066) to Yahoo! - 2 upvotes, $0
42. [XSS Reflected - Yahoo Travel](https://hackerone.com/reports/1553) to Yahoo! - 2 upvotes, $0
43. [Yahoo mail login page bruteforce protection bypass](https://hackerone.com/reports/2596) to Yahoo! - 2 upvotes, $0
44. [Clickjacking at surveylink.yahoo.com](https://hackerone.com/reports/3578) to Yahoo! - 2 upvotes, $0
45. [Almost all the subdomains are infected.](https://hackerone.com/reports/4359) to Yahoo! - 2 upvotes, $0
46. [http://us.rd.yahoo.com/](https://hackerone.com/reports/12035) to Yahoo! - 2 upvotes, $0
47. [XSS on Every sports.yahoo.com page](https://hackerone.com/reports/2168) to Yahoo! - 1 upvotes, $1500
48. [Server Side Request Forgery](https://hackerone.com/reports/4461) to Yahoo! - 1 upvotes, $500
49. [XSS in https://hk.user.auctions.yahoo.com](https://hackerone.com/reports/7266) to Yahoo! - 1 upvotes, $500
50. [Comment Spoofing  at  http://suggestions.yahoo.com/detail/?prop=directory&fid=97721](https://hackerone.com/reports/6665) to Yahoo! - 1 upvotes, $500
51. [Cross-origin issue on rmaiauth.ads.vip.bf1.yahoo.com](https://hackerone.com/reports/6268) to Yahoo! - 1 upvotes, $250
52. [Yahoo! Reflected XSS](https://hackerone.com/reports/18279) to Yahoo! - 1 upvotes, $250
53. [Yahoo open redirect using ad](https://hackerone.com/reports/2322) to Yahoo! - 1 upvotes, $0
54. [A csrf vulnerability which add and remove a favorite team from a user account.](https://hackerone.com/reports/1620) to Yahoo! - 1 upvotes, $0
55. [Insufficient validation of redirect URL on login page allows hijacking user name and password](https://hackerone.com/reports/2126) to Yahoo! - 1 upvotes, $0
56. [Reflected XSS in mail.yahoo.com](https://hackerone.com/reports/2240) to Yahoo! - 1 upvotes, $0
57. [Authentication bypass at fast.corp.yahoo.com](https://hackerone.com/reports/3577) to Yahoo! - 1 upvotes, $0
58. [Information Disclosure, groups.yahoo.com,6-april-2014, #SpringClean](https://hackerone.com/reports/5986) to Yahoo! - 1 upvotes, $0
59. [clickjacking on leaving group(flick)](https://hackerone.com/reports/7745) to Yahoo! - 1 upvotes, $0
60. [Yahoo! Messenger v11.5.0.228 emoticons.xml shortcut Value Handling Stack-Based Buffer Overflow](https://hackerone.com/reports/10767) to Yahoo! - 1 upvotes, $0
61. [Open Proxy, http://www.smushit.com/ysmush.it/, 4/09/14, #SpringClean](https://hackerone.com/reports/6704) to Yahoo! - 0 upvotes, $2000
62. [CSRF Token missing on  http://baseball.fantasysports.yahoo.com/b1/127146/messages](https://hackerone.com/reports/6700) to Yahoo! - 0 upvotes, $400
63. [Infrastructure and Application Admin Interfaces (OWASP‐CM‐007)](https://hackerone.com/reports/11414) to Yahoo! - 0 upvotes, $250
64. [Yahoo Sports Fantasy Golf (Join Public Group)](https://hackerone.com/reports/16414) to Yahoo! - 0 upvotes, $200
65. [CSRF Token is missing on DELETE message option on  http://baseball.fantasysports.yahoo.com/b1/127146/messages](https://hackerone.com/reports/6702) to Yahoo! - 0 upvotes, $200
66. [Testing for user enumeration (OWASP‐AT‐002) - https://gh.bouncer.login.yahoo.com](https://hackerone.com/reports/12708) to Yahoo! - 0 upvotes, $100
67. [Authorization issue on creative.yahoo.com](https://hackerone.com/reports/12685) to Yahoo! - 0 upvotes, $50
68. [Open redirect on tw.money.yahoo.com](https://hackerone.com/reports/4570) to Yahoo! - 0 upvotes, $0
69. [TESTING FOR REFLECTED CROSS SITE SCRIPTING (OWASP‐DV‐001)](https://hackerone.com/reports/12011) to Yahoo! - 0 upvotes, $0
70. [Multiple vulnerabilities](https://hackerone.com/reports/14248) to Yahoo! - 0 upvotes, $0
71. [URL Redirection](https://hackerone.com/reports/1429) to Yahoo! - 0 upvotes, $0
72. [clickjacking ](https://hackerone.com/reports/1207) to Yahoo! - 0 upvotes, $0
73. [Authentication Bypass in Yahoo Groups](https://hackerone.com/reports/1209) to Yahoo! - 0 upvotes, $0
74. [Open URL Redirection](https://hackerone.com/reports/4521) to Yahoo! - 0 upvotes, $0
75. [Out of date version](https://hackerone.com/reports/5221) to Yahoo! - 0 upvotes, $0
76. [Authentication Bypass due to Session Mismanagement](https://hackerone.com/reports/10912) to Yahoo! - 0 upvotes, $0
