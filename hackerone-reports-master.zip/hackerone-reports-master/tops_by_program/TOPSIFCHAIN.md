Top reports from Sifchain program at HackerOne:

1. [Subdomain Takeover At the Main Domain Of Your Site ](https://hackerone.com/reports/1183296) to Sifchain - 32 upvotes, $200
2. [xmlrpc.php And /wp-json/wp/v2/users FILE IS enable it will used for bruteforce attack and denial of service](https://hackerone.com/reports/1147449) to Sifchain - 17 upvotes, $50
3. [Clickjacking Vulnerability in sifchain.finance](https://hackerone.com/reports/1185949) to Sifchain - 11 upvotes, $0
4. [Information Disclosure on https://rpc.sifchain.finance/](https://hackerone.com/reports/1197035) to Sifchain - 10 upvotes, $0
5. [Wrong implementation of Telegram link on the main page for PC users](https://hackerone.com/reports/1194293) to Sifchain - 7 upvotes, $100
6. [Subdomain Takeover on proxies.sifchain.finance pointing to vercel](https://hackerone.com/reports/1487793) to Sifchain - 6 upvotes, $100
7. [Vulnerable for clickjacking attack](https://hackerone.com/reports/1188639) to Sifchain - 6 upvotes, $0
8. [Email Spoofing on sifchain.finance](https://hackerone.com/reports/1191209) to Sifchain - 6 upvotes, $0
9. [Path Transversal inside saveContracts.js](https://hackerone.com/reports/1196917) to Sifchain - 6 upvotes, $0
10. [Clickjacking misconfiguration bug](https://hackerone.com/reports/1176104) to Sifchain - 6 upvotes, $0
11. [wrong url in hackerone \> goes to wix.com \> unconnected](https://hackerone.com/reports/1187018) to Sifchain - 5 upvotes, $200
12. [Wrong Url in Main Page](https://hackerone.com/reports/1188629) to Sifchain - 4 upvotes, $200
13. [Private RSA key for Vagrant exposed in GitHub repository](https://hackerone.com/reports/1183502) to Sifchain - 4 upvotes, $0
14. [A password in plain text in conf file](https://hackerone.com/reports/1188188) to Sifchain - 4 upvotes, $0
15. [Cross Origin Resource Sharing Misconfiguration | Lead to sensitive information.](https://hackerone.com/reports/1189363) to Sifchain - 4 upvotes, $0
16. [Flaws In Social media Icon on error page which can lead to financial loss to a company.](https://hackerone.com/reports/1186926) to Sifchain - 4 upvotes, $0
17. [CORS misconfiguration](https://hackerone.com/reports/1187543) to Sifchain - 4 upvotes, $0
18. [Private KEY of crypto wallet](https://hackerone.com/reports/1145581) to Sifchain - 3 upvotes, $0
19. [RSA PRIVATE KEY discloser](https://hackerone.com/reports/1183520) to Sifchain - 3 upvotes, $0
20. [ ETHEREUM_PRIVATE_KEY leaked via Open Github Repository](https://hackerone.com/reports/1133670) to Sifchain - 3 upvotes, $0
21. [Found key_adress and key_password in GitHub history](https://hackerone.com/reports/1188982) to Sifchain - 3 upvotes, $0
22. [Email spoofing](https://hackerone.com/reports/1187511) to Sifchain - 3 upvotes, $0
23. [No Rate Limit protection in user subscription form](https://hackerone.com/reports/1195429) to Sifchain - 3 upvotes, $0
24. [Private eth key found](https://hackerone.com/reports/1181213) to Sifchain - 3 upvotes, $0
25. [CORS Misconfiguration Leads to Sensitive Exposure on  Sifchain main domain](https://hackerone.com/reports/1188684) to Sifchain - 3 upvotes, $0
26. [Exposed Openapi Token](https://hackerone.com/reports/1132690) to Sifchain - 2 upvotes, $0
27. [ETHEREUM_PRIVATE_KEY leaked ](https://hackerone.com/reports/1183269) to Sifchain - 2 upvotes, $0
28. [Social media links not working](https://hackerone.com/reports/1189282) to Sifchain - 2 upvotes, $0
29. [CORS Misconfiguration](https://hackerone.com/reports/1194280) to Sifchain - 2 upvotes, $0
30. [Wordpress Users Disclosure (/wp-json/wp/v2/users/) on sifchain.finance](https://hackerone.com/reports/1195194) to Sifchain - 2 upvotes, $0
31. [Found a url on source code which was disclosing different juicy informations like ip addresses and available endponts](https://hackerone.com/reports/1195432) to Sifchain - 2 upvotes, $0
32. [No Valid SPF Records/don't have DMARC record](https://hackerone.com/reports/1194598) to Sifchain - 2 upvotes, $0
33. [Open S3 Bucket | information leakage](https://hackerone.com/reports/1186897) to Sifchain - 2 upvotes, $0
34. [CORS (Cross-Origin Resource Sharing) origin validation failure -Any website can issue requests made with user credentials and read the responses to th](https://hackerone.com/reports/1188471) to Sifchain - 2 upvotes, $0
35. [Error Page Content Spoofing or Text Injection](https://hackerone.com/reports/1196253) to Sifchain - 2 upvotes, $0
36. [Bootstrap library is vulnerable](https://hackerone.com/reports/1198203) to Sifchain - 2 upvotes, $0
37. [Possible Database Details stored in values.yaml](https://hackerone.com/reports/1199803) to Sifchain - 2 upvotes, $0
38. [CORS (Cross-Origin Resource Sharing) origin validation failure](https://hackerone.com/reports/1192147) to Sifchain - 2 upvotes, $0
39. [Possibility of DoS attack at https://sifchain.finance// via CVE-2018-6389 exploitation](https://hackerone.com/reports/1186985) to Sifchain - 1 upvotes, $0
40. [mongodb credentials leaked in github](https://hackerone.com/reports/1183809) to Sifchain - 1 upvotes, $0
41. [ Information disclosure on Sifchain](https://hackerone.com/reports/1188998) to Sifchain - 1 upvotes, $0
42. [HTTPS not enforced at dex.sifchain.finance](https://hackerone.com/reports/1126401) to Sifchain - 1 upvotes, $0
43. [Cross-site Scripting (XSS) possible  at https://sifchain.finance// via CVE-2019-8331 exploitation](https://hackerone.com/reports/1218173) to Sifchain - 1 upvotes, $0
44. [Origin IP Disclosure Vulnerability](https://hackerone.com/reports/1327443) to Sifchain - 1 upvotes, $0
45. [4 xss vulnerability dom based cwe 79 ; wordpress bootstrap.min.js is vulnerable](https://hackerone.com/reports/1219002) to Sifchain - 1 upvotes, $0
46. [ETHEREUM_PRIVATE_KEY leaked via github](https://hackerone.com/reports/1283605) to Sifchain - 1 upvotes, $0
47. [Sifchain token leak ](https://hackerone.com/reports/1188938) to Sifchain - 1 upvotes, $0
48. [Clickjacking](https://hackerone.com/reports/1206138) to Sifchain - 1 upvotes, $0
49. [CSRF in newsletter form](https://hackerone.com/reports/1190705) to Sifchain - 1 upvotes, $0
50. [No Rate Limit in email leads to huge Mass mailings](https://hackerone.com/reports/1185903) to Sifchain - 1 upvotes, $0
51. [Username disclosure at Main Domain](https://hackerone.com/reports/1188662) to Sifchain - 1 upvotes, $0
52. [No valid SPF record found](https://hackerone.com/reports/1187001) to Sifchain - 1 upvotes, $0
53. [Vulnerability : Email Spoofing](https://hackerone.com/reports/1180668) to Sifchain - 1 upvotes, $0
54. [Linux Desktop application "sifnoded" executable does not use Pie / no ASLR](https://hackerone.com/reports/1188633) to Sifchain - 1 upvotes, $0
55. [Vulnerable javascript dependency at Main domain](https://hackerone.com/reports/1188643) to Sifchain - 0 upvotes, $0
56. [SSH server due to Improper Signature Verification](https://hackerone.com/reports/1294043) to Sifchain - 0 upvotes, $0
57. [Email Spoofing bug](https://hackerone.com/reports/1176090) to Sifchain - 0 upvotes, $0
58. [Dependency Confusion Vulnerability in Sifnode Due to Unclaimed npm Packages.](https://hackerone.com/reports/1187816) to Sifchain - 0 upvotes, $0
59. [Signature Verification /// golang.org/x/crypto/ssh](https://hackerone.com/reports/1276384) to Sifchain - 0 upvotes, $0
60. [information disclosure](https://hackerone.com/reports/1218784) to Sifchain - 0 upvotes, $0
61. [clickjacking vulnerability](https://hackerone.com/reports/1199904) to Sifchain - 0 upvotes, $0
62. [	 Clickjacking at sifchain.finance](https://hackerone.com/reports/1212595) to Sifchain - 0 upvotes, $0
63. [Wrong Url in Main page of sifchain.finance](https://hackerone.com/reports/1195512) to Sifchain - 0 upvotes, $0
64. [Wrong Implementation of Url in https://docs.sifchain.finance/](https://hackerone.com/reports/1198877) to Sifchain - 0 upvotes, $0
65. [Session Token in URL](https://hackerone.com/reports/1197078) to Sifchain - 0 upvotes, $0
66. [No Valid SPF Records at sifchain.finance](https://hackerone.com/reports/1188725) to Sifchain - 0 upvotes, $0
67. [Clickjacking /framing on sensitive Subdomain ](https://hackerone.com/reports/1195209) to Sifchain - 0 upvotes, $0
68. [Sifchain Privacy Policy Webpage Uses Wordpress Default Template. Does Not Display Correct Privacy Policy.](https://hackerone.com/reports/1196049) to Sifchain - 0 upvotes, $0
69. [Information Disclosure at one of your subdomain](https://hackerone.com/reports/1195423) to Sifchain - 0 upvotes, $0
70. [Design Issues at Main Domain](https://hackerone.com/reports/1188652) to Sifchain - 0 upvotes, $0
71. [Misconfiguration Certificate Authority Authorization Rule](https://hackerone.com/reports/1186740) to Sifchain - 0 upvotes, $0
