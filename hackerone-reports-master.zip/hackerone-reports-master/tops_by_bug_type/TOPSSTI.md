Top SSTI reports from HackerOne:

1. [H1514 Server Side Template Injection in Return Magic email templates?](https://hackerone.com/reports/423541) to Shopify - 407 upvotes, $0
2. [Path traversal, SSTI and RCE on a MailRu acquisition ](https://hackerone.com/reports/536130) to Mail.ru - 152 upvotes, $2000
3. [Urgent: Server side template injection via Smarty template allows for RCE](https://hackerone.com/reports/164224) to Unikrn - 121 upvotes, $0
4. [Reflected XSS and Server Side Template Injection  in all HubSpot CMSes](https://hackerone.com/reports/399462) to HubSpot Inactive - 64 upvotes, $0
5. [Python : Add query to detect Server Side Template Injection](https://hackerone.com/reports/944359) to GitHub Security Lab - 29 upvotes, $0
6. [Server Side Template Injection on Name parameter during Sign Up process](https://hackerone.com/reports/1104349) to Glovo - 26 upvotes, $0
7. [[Ruby]: Server Side Template Injection](https://hackerone.com/reports/1928279) to GitHub Security Lab - 13 upvotes, $2300
8. [CodeQL query to detect Server-Side Template Injections (JavaScript)](https://hackerone.com/reports/894872) to GitHub Security Lab - 8 upvotes, $0
9. [Server-side Template Injection in lodash.js ](https://hackerone.com/reports/904672) to Node.js third-party modules - 7 upvotes, $0
10. [Server-side template injection at ujs test server](https://hackerone.com/reports/942103) to Ruby on Rails - 5 upvotes, $0
11. [Java : Add query to detect Server Side Template Injection (SSTI)](https://hackerone.com/reports/1490372) to GitHub Security Lab - 4 upvotes, $0
