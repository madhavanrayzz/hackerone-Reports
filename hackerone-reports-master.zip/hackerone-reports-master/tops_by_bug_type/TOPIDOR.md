Top IDOR reports from HackerOne:

1. [IDOR to add secondary users in www.paypal.com/businessmanage/users/api/v1/users](https://hackerone.com/reports/415081) to PayPal - 762 upvotes, $10500
2. [IDOR allow access to payments data of any user](https://hackerone.com/reports/751577) to Nord Security - 374 upvotes, $0
3. [IDOR - Delete all Licenses and certifications from users account using CreateOrUpdateHackerCertification GraphQL query](https://hackerone.com/reports/2122671) to HackerOne - 364 upvotes, $12500
4. [Insecure Direct Object Reference (IDOR) - Delete Campaigns  ](https://hackerone.com/reports/1969141) to HackerOne - 334 upvotes, $0
5. [idor allows you to delete photos and album from a gallery](https://hackerone.com/reports/380410) to Pornhub - 266 upvotes, $1500
6. [Singapore - Account Takeover via IDOR](https://hackerone.com/reports/876300) to Starbucks - 251 upvotes, $0
7. [IDOR allows any user to edit others videos](https://hackerone.com/reports/681473) to Pornhub - 248 upvotes, $1500
8. [Insecure Direct Object Reference (IDOR) Allows Viewing Private Report Details via /bugs.json Endpoint](https://hackerone.com/reports/2487889) to HackerOne - 230 upvotes, $0
9. [An IDOR that can lead to enumeration of a user and disclosure of email and phone number within cashier](https://hackerone.com/reports/1966006) to Unikrn - 217 upvotes, $3000
10. [IDOR delete any Tickets on ads.tiktok.com](https://hackerone.com/reports/1475520) to TikTok - 210 upvotes, $0
11. [I.D.O.R To Order,Book,Buy,reserve On YELP FOR FREE (UNAUTHORIZED USE OF OTHER USER'S CREDIT CARD)](https://hackerone.com/reports/391092) to Yelp - 208 upvotes, $0
12. [IDOR: Account Deletion via Session Misbinding – Attacker Can Delete Victim Account](https://hackerone.com/reports/3154983) to Mozilla - 207 upvotes, $0
13. [IDOR when editing users leads to Account Takeover without User Interaction at CrowdSignal](https://hackerone.com/reports/915114) to Automattic - 197 upvotes, $0
14. [IDOR vulnerability in unreleased HackerOne Copilot feature](https://hackerone.com/reports/2218334) to HackerOne - 197 upvotes, $0
15. [IDOR allows an attacker to modify the links of any user](https://hackerone.com/reports/1661113) to Reddit - 194 upvotes, $0
16. [IDOR in the https://market.semrush.com/](https://hackerone.com/reports/837400) to Semrush - 169 upvotes, $0
17. [IDOR leads to Edit Anyone's Blogs / Websites](https://hackerone.com/reports/974222) to Automattic - 169 upvotes, $0
18. [IDOR on GraphQL queries BillingDocumentDownload and BillDetails](https://hackerone.com/reports/2207248) to Shopify - 162 upvotes, $5000
19. [IDOR Vulnerability at AddTagToAssets operation name](https://hackerone.com/reports/2633771) to HackerOne - 154 upvotes, $0
20. [Getting access of mod logs from any public or restricted subreddit with IDOR vulnerability](https://hackerone.com/reports/1658418) to Reddit - 145 upvotes, $5000
21. [IDOR vulnerability (Price manipulation)](https://hackerone.com/reports/1403176) to Acronis - 141 upvotes, $0
22. [IDOR and statistics leakage in Orders ](https://hackerone.com/reports/544329) to X / xAI - 133 upvotes, $289
23. [[api.pandao.ru] IDOR for order delivery address](https://hackerone.com/reports/723461) to Mail.ru - 125 upvotes, $3000
24. [IDOR in https://3d.cs.money/](https://hackerone.com/reports/990878) to CS Money - 121 upvotes, $0
25. [IDOR leads to leak analytics of any restaurant](https://hackerone.com/reports/1116387) to Uber - 118 upvotes, $0
26. [IDOR to view order information of users and personal information](https://hackerone.com/reports/2524562) to WakaTime - 118 upvotes, $0
27. [IDOR at mtnmobad.mtnbusiness.com.ng leads to PII leakage. ](https://hackerone.com/reports/1773609) to MTN Group - 118 upvotes, $0
28. [IDOR on ads.tiktok.com Allows Unauthorized Product Addition](https://hackerone.com/reports/2848610) to TikTok - 117 upvotes, $500
29. [IDOR on in-app hardcoded zombie endpoint  ](https://hackerone.com/reports/3085742) to Bykea - 117 upvotes, $0
30. [IDOR for changing privacy settings on any memories](https://hackerone.com/reports/1733627) to TikTok - 112 upvotes, $0
31. [IDOR leading to downloading of any attachment](https://hackerone.com/reports/668439) to BCM Messenger - 110 upvotes, $0
32. [IDOR leads to See analytics of Loyalty Program in any restaurant.](https://hackerone.com/reports/1137819) to Uber - 107 upvotes, $0
33. [IDOR on TikTok Ads Endpoint](https://hackerone.com/reports/1527906) to TikTok - 104 upvotes, $2500
34. [IDOR allowing to read another user's token on the Social Media Ads service](https://hackerone.com/reports/1464168) to Semrush - 97 upvotes, $0
35. [IDOR Exposes All Machine Learning Models](https://hackerone.com/reports/2528293) to GitLab - 95 upvotes, $1160
36. [IDOR vulnerability reveals additional information](https://hackerone.com/reports/1770858) to Semrush - 90 upvotes, $0
37. [[unibet.com] Delete messages via IDOR at /mom-api/messages/unibet_█████████@unibet/](https://hackerone.com/reports/697412) to Kindred Group - 89 upvotes, $0
38. [IDOR when moving contents at CrowdSignal](https://hackerone.com/reports/915127) to Automattic - 87 upvotes, $0
39. [Access User Tickets via IDOR in [widget.support.my.games]](https://hackerone.com/reports/1005315) to Mail.ru - 86 upvotes, $0
40. [IDOR Leads To  User Profile Modification https://mtnmobad.mtnbusiness.com.ng/app/updateUser](https://hackerone.com/reports/1714638) to MTN Group - 86 upvotes, $0
41. [CRITICAL Insecure Direct Object Reference (I.D.O.R) - Link Other User's Credit Card ](https://hackerone.com/reports/358143) to Yelp - 85 upvotes, $0
42. [IDOR - Leaking of team data (name, email, ID, member ID) via POST /api/v1/graphql  `FetchMemberships` operation](https://hackerone.com/reports/2381816) to Tools for Humanity - 83 upvotes, $500
43. [IDOR allows an attacker to delete anyone's featured photo.](https://hackerone.com/reports/1608735) to LinkedIn - 83 upvotes, $0
44. [Cross-Tenant IDOR ( graphql `AddRulesToPixelEvents` query ) allowing to add, update, and delete rules of any Pixel events on the platform](https://hackerone.com/reports/984965) to TikTok - 80 upvotes, $0
45. [IDOR to view order information of users and personal information](https://hackerone.com/reports/1323406) to Affirm - 78 upvotes, $500
46. [IDOR via internal_api "users" endpoint ](https://hackerone.com/reports/349291) to New Relic - 77 upvotes, $1500
47. [IDOR vulnerability leads to Deleting message after leaving/getting banned from group using message ID](https://hackerone.com/reports/2028450) to Rocket.Chat - 76 upvotes, $0
48. [IDOR on Delete Email address features](https://hackerone.com/reports/2382484) to Mozilla - 75 upvotes, $0
49. [Insecure Direct Object Reference (IDOR) in GraphQL deleteProfileImages Mutation](https://hackerone.com/reports/2968039) to Autodesk - 73 upvotes, $0
50. [IDOR the ability to view support tickets of any user on seller platform](https://hackerone.com/reports/1392630) to TikTok - 72 upvotes, $2500
51. [RCE, SQLi, IDOR, Auth Bypass and XSS at [staff.███.edu.eg ]](https://hackerone.com/reports/404874) to ██████ - 72 upvotes, $0
52. [Unauthorized Reservation Cancellation Through IDOR Vulnerability](https://hackerone.com/reports/2944357) to Yelp - 71 upvotes, $0
53. [IDOR on HackerOne Feedback Review](https://hackerone.com/reports/262661) to HackerOne - 70 upvotes, $0
54. [IDOR leading unauthenticated attacker to download documents discloses PII of users and soldiers via https://www.█████████/Download.aspx?id= [HtUS]](https://hackerone.com/reports/1626508) to U.S. Dept Of Defense - 68 upvotes, $500
55. [IDOR vulnerability on profile picture changing mechanism which discloses other user's profile picture.](https://hackerone.com/reports/2024284) to Glassdoor - 68 upvotes, $0
56. [IDOR allows information disclosure](https://hackerone.com/reports/1816900) to Semrush - 68 upvotes, $0
57. [Insecure Direct Object Reference (IDOR) Vulnerability in Autodesk User Profile](https://hackerone.com/reports/2965357) to Autodesk - 67 upvotes, $0
58. [IDOR - Scheduled data leak to other accounts By "projectID"](https://hackerone.com/reports/3219944) to SingleStore - 67 upvotes, $0
59. [IDOR Vulnerability Allowing Unauthorized Profile Picture Change](https://hackerone.com/reports/2962056) to Autodesk - 63 upvotes, $0
60. [Ability to add arbitrary images/descriptions/titles to ohter people's issues via IDOR on getrevue.co](https://hackerone.com/reports/1096560) to X / xAI - 62 upvotes, $0
61. [Insecure Direct Object Reference allows Crew Invite deletion](https://hackerone.com/reports/1947924) to Rockstar Games - 62 upvotes, $0
62. [IDOR to delete images from other stores](https://hackerone.com/reports/404797) to Eternal - 61 upvotes, $600
63. [IDOR in Report CSV export discloses the IDs of Custom Field Attributes of Programs](https://hackerone.com/reports/510759) to HackerOne - 60 upvotes, $0
64. [IDOR on Tagged People](https://hackerone.com/reports/1555376) to TikTok - 60 upvotes, $0
65. [IDOR in marketing calendar tool](https://hackerone.com/reports/797685) to Semrush - 59 upvotes, $0
66. [Upload profile photo and  Pets addition - IDOR](https://hackerone.com/reports/2393021) to Mars - 59 upvotes, $0
67. [IDOR with Geolocation data not stripped from images](https://hackerone.com/reports/906907) to IRCCloud - 58 upvotes, $200
68. [IDOR leads to PII Leak](https://hackerone.com/reports/2586584) to U.S. Dept Of Defense - 58 upvotes, $0
69. [IDOR when creating App on [platform.streamlabs.com/api/v1/store/whitelist] with user_id field](https://hackerone.com/reports/983070) to Logitech - 57 upvotes, $0
70. [Insecure direct Object Reference(Horizontal Escalation)](https://hackerone.com/reports/2322663) to MTN Group - 54 upvotes, $0
71. [IDOR in upload videos of a Channel on https://video.ibm.com](https://hackerone.com/reports/2085185) to IBM - 53 upvotes, $0
72. [IDOR in backup recovery functionality](https://hackerone.com/reports/1901713) to Acronis - 53 upvotes, $0
73. [CSRF combined with IDOR within Document Converter exposes files](https://hackerone.com/reports/398316) to Open-Xchange - 52 upvotes, $500
74. [IDOR in Stats API Endpoint Allows Viewing Equity or Net Profit of Any MT Account ](https://hackerone.com/reports/1644436) to EXNESS - 52 upvotes, $0
75. [IDOR may allow access to non-public photos](https://hackerone.com/reports/1737943) to Flickr - 52 upvotes, $0
76. [IDOR in API applications (able to see any API token, leads to account takeover)](https://hackerone.com/reports/1695454) to Automattic - 51 upvotes, $0
77. [Insecure Direct Object Reference Protection bypass by changing HTTP method in IBM Your Learning endpoint. ](https://hackerone.com/reports/2456603) to IBM - 51 upvotes, $0
78. [IDOR of users ](https://hackerone.com/reports/743687) to Mail.ru - 48 upvotes, $500
79. [IDOR to delete profile images in https:███████](https://hackerone.com/reports/2213900) to U.S. Dept Of Defense - 46 upvotes, $0
80. [IDOR in semrush academy](https://hackerone.com/reports/783708) to Semrush - 45 upvotes, $0
81. [IDOR - Delete technical skill assessment result & Gained Badges result of any user](https://hackerone.com/reports/1592587) to LinkedIn - 44 upvotes, $0
82. [IDOR in sending support email upon Verifying user business domain](https://hackerone.com/reports/592090) to Trustpilot - 43 upvotes, $0
83. [IDOR when editing email leads to Account Takeover on Atavist](https://hackerone.com/reports/950881) to Automattic - 43 upvotes, $0
84. [China - IDOR on Reservation Staging/Non Production Site - https://reservation.stg.starbucks.com.cn](https://hackerone.com/reports/715054) to Starbucks - 42 upvotes, $0
85. [IDOR: leak buyer info & Publish/Hide foreign comments](https://hackerone.com/reports/1410498) to Judge.me  - 40 upvotes, $0
86. [Sensei LMS IDOR to send message](https://hackerone.com/reports/1592596) to Automattic - 40 upvotes, $0
87. [IDOR on www.acronis.com API lead to steal private business user information](https://hackerone.com/reports/1182465) to Acronis - 39 upvotes, $100
88. [IDOR in family pairing API](https://hackerone.com/reports/1586950) to TikTok - 39 upvotes, $0
89. [IDOR to account takeover on POST to █████████ by changing member_id parameter](https://hackerone.com/reports/2132183) to Mars - 39 upvotes, $0
90. [IDOR in one subdomain of █████████ -\> change information of pets without athorization!](https://hackerone.com/reports/2073950) to Mars - 39 upvotes, $0
91. [IDOR lets a malicious user reveal the unpinned achievement badges of any Reddit user](https://hackerone.com/reports/2618486) to Reddit - 38 upvotes, $0
92. [IDOR  leads to view other user Biographical details (Possible PII LEAK)](https://hackerone.com/reports/2586641) to U.S. Dept Of Defense - 37 upvotes, $0
93. [IDOR в списке пользователей по домену в relap.io](https://hackerone.com/reports/739752) to Mail.ru - 36 upvotes, $0
94. [IDOR in TalentMAP API can be abused to enumerate personal information of all the users](https://hackerone.com/reports/1848176) to U.S. Department of State - 36 upvotes, $0
95. [IDOR : Modify other users demographic details](https://hackerone.com/reports/2586662) to U.S. Dept Of Defense - 36 upvotes, $0
96. [IDOR to cancel any table booking and leak sensitive information such as email,mobile number,uuid](https://hackerone.com/reports/265258) to Eternal - 35 upvotes, $250
97. [IDOR Payments Status](https://hackerone.com/reports/1538669) to Omise - 35 upvotes, $100
98. [\<- Critical IDOR vulnerability in socialclub allow to insert and delete comments as another user and it discloses sensitive information -\>](https://hackerone.com/reports/204292) to Rockstar Games - 35 upvotes, $0
99. [[api.pandao.ru] IDOR позволяет изменять адрес любого пользователя](https://hackerone.com/reports/484339) to Mail.ru - 33 upvotes, $1000
100. [IDOR in editing courses](https://hackerone.com/reports/227522) to Radancy - 33 upvotes, $0
101. [Thailand - Insecure Direct Object Reference permits an unauthorized user to transfer funds from a victim using only the victims Starbucks card](https://hackerone.com/reports/766437) to Starbucks - 33 upvotes, $0
102. [IDOR смена email пользователя через Ситимобил Бизнес](https://hackerone.com/reports/971422) to Mail.ru - 33 upvotes, $0
103. [IDOR - disclosure of private videos - /api_android_v3/getUserVideos](https://hackerone.com/reports/186279) to Pornhub - 32 upvotes, $1500
104. [IDOR to pay less for coin purchases on oauth.reddit.com via /api/v2/gold/paypal/create_coin_purchase_order in `order_id` parameter ](https://hackerone.com/reports/1213765) to Reddit - 32 upvotes, $500
105. [Idor on the DELETE /comments/](https://hackerone.com/reports/861849) to RGhost - 32 upvotes, $0
106. [No error thrown when IDOR attempted while editing address](https://hackerone.com/reports/1085743) to OpenMage - 32 upvotes, $0
107. [Ability to read any emails through IDOR on Nextcloud Mail](https://hackerone.com/reports/1784681) to Nextcloud - 32 upvotes, $0
108. [IDOR bug to See hidden slowvote of any user even when you dont have access right](https://hackerone.com/reports/661978) to Phabricator - 31 upvotes, $300
109. [[www.zomato.com] IDOR - Leaking all Personal Details of all Zomato Users through an endpoint](https://hackerone.com/reports/269937) to Eternal - 31 upvotes, $0
110. [IDOR to view User Order Information](https://hackerone.com/reports/287789) to BOHEMIA INTERACTIVE a.s. - 31 upvotes, $0
111. [IDOR on deleting drafts on https://apps.topcoder.com/wiki/users/viewmydrafts.action via discardDraftId parameter](https://hackerone.com/reports/868590) to Lab45 - 31 upvotes, $0
112. [IDOR in "external status check" API leaks data about any status check on the instance](https://hackerone.com/reports/1372216) to GitLab - 30 upvotes, $610
113. [IDOR in changing shared file name](https://hackerone.com/reports/547663) to Trint Ltd - 30 upvotes, $0
114. [I.D.O.R TO EDIT ALL USER'S CREDIT CARD INFORMATION+(Partial credit card info disclosure)](https://hackerone.com/reports/361984) to Yelp - 30 upvotes, $0
115. [IDOR on TikTok Seller](https://hackerone.com/reports/1509057) to TikTok - 29 upvotes, $500
116. [IDOR in Bugs overview enables attacker to determine the date range a hackathon was active](https://hackerone.com/reports/663431) to HackerOne - 29 upvotes, $0
117. [Corss-Tenant IDOR on Business allowing escalation privilege, invitation takeover, and edition of any other Businesses' employees](https://hackerone.com/reports/1063022) to Uber - 29 upvotes, $0
118. [[NR Insights] IDOR - Modify the filter settings for any NR Insights dashboard through internal_api endpoint](https://hackerone.com/reports/459443) to New Relic - 28 upvotes, $2500
119. [IDOR [partners.shopify.com] - User with ONLY Manage apps permission is able to get shops info and staff names from inside the shop](https://hackerone.com/reports/243943) to Shopify - 28 upvotes, $500
120. [IDOR on Program Visibilty (Revealed / Concealed) against other team members](https://hackerone.com/reports/291721) to HackerOne - 28 upvotes, $0
121. [IDOR - Other user's delivery address disclosed](https://hackerone.com/reports/964010) to Azbuka Vkusa - 27 upvotes, $0
122. [IDOR Leads To Account Takeover Without User Interaction](https://hackerone.com/reports/1272478) to MTN Group - 27 upvotes, $0
123. [IDOR  [mtnmobad.mtnbusiness.com.ng]](https://hackerone.com/reports/1698006) to MTN Group - 27 upvotes, $0
124. [IDOR - Downloading all attachements if having access to a shared link](https://hackerone.com/reports/194790) to Open-Xchange - 26 upvotes, $888
125. [IDOR Causing Deletion of any account](https://hackerone.com/reports/156537) to Ubiquiti Inc. - 26 upvotes, $0
126. [IDOR unsubscribe Anyone from NextClouds Newsletters by knowing their Email ](https://hackerone.com/reports/230328) to Nextcloud - 26 upvotes, $0
127. [Thailand - IDOR on www.starbuckscardth.in.th: A logged in user could view any Thailand Starbucks card balance if they knew that Starbucks card number](https://hackerone.com/reports/858662) to Starbucks - 26 upvotes, $0
128. [█████████ IDOR leads to disclosure of PHI/PII](https://hackerone.com/reports/1085782) to U.S. Dept Of Defense - 26 upvotes, $0
129. [Vimeo.com Insecure Direct Object References Reset Password](https://hackerone.com/reports/42587) to Vimeo - 25 upvotes, $0
130. [IDOR to Account Takeover on https://████/index.html](https://hackerone.com/reports/969223) to U.S. Dept Of Defense - 24 upvotes, $0
131. [IDOR while uploading ████ attachments at [█████████]](https://hackerone.com/reports/1196976) to U.S. Dept Of Defense - 24 upvotes, $0
132. [Remove Every User, Admin, And Owner Out Of Their Teams on developers.mtn.com via IDOR + Information Disclosure](https://hackerone.com/reports/1448550) to MTN Group - 24 upvotes, $0
133. [[app.mavenlink.com] IDOR to view sensitive information](https://hackerone.com/reports/283419) to Mavenlink - 23 upvotes, $0
134. [IDOR in activateFuelCard id allows bulk lookup of driver uuids](https://hackerone.com/reports/254151) to Uber - 23 upvotes, $0
135. [GRAPHQL cross-tenant IDOR giving write access thought the operation UpdateAtlasApplicationPerson](https://hackerone.com/reports/1066203) to Stripe - 23 upvotes, $0
136. [IDOR widget.support.my.com](https://hackerone.com/reports/328337) to Mail.ru - 22 upvotes, $0
137. [IDOR to update folder name of other user](https://hackerone.com/reports/587687) to Trint Ltd - 22 upvotes, $0
138. [IDOR Vulnerability in Job Preferences](https://hackerone.com/reports/827158) to Glassdoor - 22 upvotes, $0
139. [IDOR expire other user sessions](https://hackerone.com/reports/56511) to Shopify - 21 upvotes, $1000
140. [IDOR in eform.molpay.com leads to see other users application forms with private data](https://hackerone.com/reports/790829) to Razer - 21 upvotes, $500
141. [IDOR in report download functionality on ads.tiktok.com](https://hackerone.com/reports/1559739) to TikTok - 21 upvotes, $500
142. [IDOR - Ability to view unlisted products](https://hackerone.com/reports/172545) to Reverb.com - 21 upvotes, $0
143. [IDOR - Accessing other user's attachements via PUT /appsuite/api/files?action=saveAs](https://hackerone.com/reports/204984) to Open-Xchange - 20 upvotes, $888
144. [IDOR - Deleting other user's signature via /appsuite/api/snippet?action=update (although an error is thrown)](https://hackerone.com/reports/199321) to Open-Xchange - 20 upvotes, $300
145. [IDOR in tracking driver logs at city-mobil.ru](https://hackerone.com/reports/847876) to Mail.ru - 20 upvotes, $150
146. [Insecure Direct Object Reference (IDOR) Allowing me to claim other user's photos (driving license and selfies) as mine](https://hackerone.com/reports/268167) to Cuvva - 20 upvotes, $0
147. [[www.zomato.com] IDOR - Gold Subscription Details, Able to view "Membership ID" and "Validity Details" of other Users](https://hackerone.com/reports/344145) to Eternal - 19 upvotes, $100
148. [[www.zomato.com] IDOR - Delete/Deactivate any special menu of any Restaurants from Zomato](https://hackerone.com/reports/264919) to Eternal - 19 upvotes, $0
149. ['cnvID' parameter vulnerable to Insecure Direct Object References](https://hackerone.com/reports/265284) to Concrete CMS - 19 upvotes, $0
150. [Metadata leakage via IDOR](https://hackerone.com/reports/762707) to Polymail, Inc. - 19 upvotes, $0
151. [IDOR редактирование любого вишлиста](https://hackerone.com/reports/736065) to QIWI - 19 upvotes, $0
152. [IDOR at 'media_code' when addings media to questions](https://hackerone.com/reports/915133) to Automattic - 19 upvotes, $0
153. [IDOR on partners.uber.com allows for a driver to override administrator documents](https://hackerone.com/reports/194594) to Uber - 18 upvotes, $0
154. [Singapore - IDOR in campaign.starbucks.com.sg](https://hackerone.com/reports/783332) to Starbucks - 18 upvotes, $0
155. [IDOR on notes to HTML injection](https://hackerone.com/reports/914331) to Palo Alto Software - 18 upvotes, $0
156. [IDOR in https://moneybird.com/user/accountant_company/edit(change company name)](https://hackerone.com/reports/726163) to Moneybird - 18 upvotes, $0
157. [IDOR - Access to private video thumbnails even if video requires password authentication](https://hackerone.com/reports/197114) to Pornhub - 17 upvotes, $0
158. [View & add to cart unlisted items via IDOR](https://hackerone.com/reports/344284) to Instacart - 17 upvotes, $0
159. [IDOR on DoD Website exposes FTP users and passes linked to all accounts!](https://hackerone.com/reports/228383) to U.S. Dept Of Defense - 17 upvotes, $0
160. [IDOR on update user preferences](https://hackerone.com/reports/854290) to Palo Alto Software - 17 upvotes, $0
161. [IDOR](https://hackerone.com/reports/389250) to U.S. Dept Of Defense - 17 upvotes, $0
162. [IDOR leaking PII data via VendorId parameter](https://hackerone.com/reports/1690044) to U.S. Dept Of Defense - 17 upvotes, $0
163. [IDOR of contracts on dictor.mail.ru](https://hackerone.com/reports/923851) to Mail.ru - 16 upvotes, $150
164. [IDOR- Activate Mopub on different organizations- steal api token- Fabric.io](https://hackerone.com/reports/95552) to X / xAI - 16 upvotes, $0
165. [Comment restriction in subsection "Workshop" of domain "steamcommunity.com" can be bypassed using IDOR](https://hackerone.com/reports/365504) to Valve - 16 upvotes, $0
166. [relap.io IDOR](https://hackerone.com/reports/749887) to Mail.ru - 16 upvotes, $0
167. [IDOR at training.smartpay.gsa.gov/reports/quizzes-taken-by-user](https://hackerone.com/reports/1118638) to U.S. General Services Administration - 16 upvotes, $0
168. [Unauth IDOR to mass account takeover without user interaction on the ███████ (https://███████.edu/)](https://hackerone.com/reports/685338) to U.S. Dept Of Defense - 16 upvotes, $0
169. [IDOR - Folder names disclosure inside a domain, regardless of user](https://hackerone.com/reports/194574) to Open-Xchange - 15 upvotes, $250
170. [[www.zomato.com] IDOR - Delete/Deactivate ANY/ALL Promos through a Post Request at **clients/promoDataHandler.php**](https://hackerone.com/reports/264754) to Eternal - 15 upvotes, $0
171. [IDOR in merchant.rbmonkey.com allows deleting eShops of another user](https://hackerone.com/reports/281296) to RBKmoney - 15 upvotes, $0
172. [idor leads to leak order information](https://hackerone.com/reports/791289) to Mail.ru - 15 upvotes, $0
173. [IDOR Allows Viewer to Delete Bin's Files](https://hackerone.com/reports/1074420) to Lark Technologies - 15 upvotes, $0
174. [IDOR when editing email leads to Mass Full ATOs (Account Takeovers) without user interaction on https://██████/](https://hackerone.com/reports/1687415) to U.S. Dept Of Defense - 15 upvotes, $0
175. [[NR Alerts/Synthetics] IDOR through /policies.json with Synthetics exposes full name of other NR users](https://hackerone.com/reports/419875) to New Relic - 14 upvotes, $1500
176. [IDOR - Leaking other user's folder names from /appsuite/api/import?action=ICA](https://hackerone.com/reports/199281) to Open-Xchange - 14 upvotes, $300
177. [IDOR allow to extract all registered email](https://hackerone.com/reports/302485) to Open-Xchange - 14 upvotes, $300
178. [IDOR on mcs.mail.ru ](https://hackerone.com/reports/312555) to Mail.ru - 14 upvotes, $150
179. [IDOR + Account Takeover  [UNAUTHENTICATED]](https://hackerone.com/reports/1004750) to U.S. Dept Of Defense - 14 upvotes, $0
180. [IDOR - setAttribute action of user object in API](https://hackerone.com/reports/285432) to Open-Xchange - 13 upvotes, $400
181. [IDOR - Deleting other user's reminders just by id](https://hackerone.com/reports/198969) to Open-Xchange - 13 upvotes, $300
182. [IDOR create accounts and verify them with original account email](https://hackerone.com/reports/244636) to WakaTime - 13 upvotes, $0
183. [IDOR at https://fast.trychameleon.com/observe/v2/profiles/ via uid parameter discloses users' PII data](https://hackerone.com/reports/1073420) to Lab45 - 13 upvotes, $0
184. [IDOR to edit test/poll/quiz on relap.io](https://hackerone.com/reports/1107130) to Mail.ru - 13 upvotes, $0
185. [[Razer Pay Mobile App] IDOR within /v1_IM/friends/queryDrawRedLog allowed unauthorised access to read logs](https://hackerone.com/reports/754044) to Razer - 12 upvotes, $500
186. [IDOR to view other user folder name](https://hackerone.com/reports/333767) to Open-Xchange - 12 upvotes, $250
187. [IDOR exposes receipts of all users.](https://hackerone.com/reports/283407) to RecargaPay - 12 upvotes, $0
188. [India - An Insecure Direct Object Reference (IDOR) allowed unauthorized access to view card index number and monetary balance](https://hackerone.com/reports/701160) to Starbucks - 12 upvotes, $0
189. [IDOR on stocky application-Low Stock-Varient-Settings-Columns](https://hackerone.com/reports/853130) to Shopify - 11 upvotes, $750
190. [IDOR leads to Leakage an ██████████ Login Information](https://hackerone.com/reports/1093908) to U.S. Dept Of Defense - 11 upvotes, $0
191. [IDOR on https://██████ via POST UID enables database scraping](https://hackerone.com/reports/1048540) to U.S. Dept Of Defense - 11 upvotes, $0
192. [Insecure Direct Object Reference - access to other user/group DM's](https://hackerone.com/reports/53858) to X / xAI - 10 upvotes, $0
193. [Insecure direct object reference - have access to deleted DM's](https://hackerone.com/reports/52646) to X / xAI - 10 upvotes, $0
194. [IDOR in tender.mail.ru leading to Information Disclosure](https://hackerone.com/reports/226640) to Mail.ru - 10 upvotes, $0
195. [View another user information with IDOR vulnerability ](https://hackerone.com/reports/1004745) to U.S. Dept Of Defense - 10 upvotes, $0
196. [Generating Unlimited Free Travel Gift Invites | IDOR](https://hackerone.com/reports/49499) to Airbnb - 9 upvotes, $0
197. [IDOR in treat subscriptions](https://hackerone.com/reports/313050) to Eternal - 9 upvotes, $0
198. [[https://city-mobil.ru/taxiserv] IDOR leads to information disclosure](https://hackerone.com/reports/746513) to Mail.ru - 9 upvotes, $0
199. [IDOR zakazaka (состояние заказа и перезаказ)](https://hackerone.com/reports/956799) to Mail.ru - 9 upvotes, $0
200. [IDOR to delete test/poll/quiz on relap.io](https://hackerone.com/reports/1107126) to Mail.ru - 9 upvotes, $0
201. [IDOR at https://demo.sftool.gov/TwsHome/ScorecardManage/ via scorecard name](https://hackerone.com/reports/1472721) to U.S. General Services Administration - 9 upvotes, $0
202. [IDOR able to buy a plan with lesser fee](https://hackerone.com/reports/1679276) to Automattic - 9 upvotes, $0
203. [Insecure Direct Object Reference vulnerability](https://hackerone.com/reports/46397) to HackerOne - 8 upvotes, $500
204. [[upload-X.my.mail.ru] /uploadphoto Insecure Direct Object References](https://hackerone.com/reports/140548) to Mail.ru - 8 upvotes, $160
205. [IDOR - Disable sharing](https://hackerone.com/reports/153905) to Nextcloud - 8 upvotes, $0
206. [Insecure Direct Object Reference (IDOR) vulnerability in a DoD website](https://hackerone.com/reports/207099) to U.S. Dept Of Defense - 8 upvotes, $0
207. [idor on upload profile functionality ](https://hackerone.com/reports/741683) to U.S. Dept Of Defense - 8 upvotes, $0
208. [Full Account Take-Over of ████████ Members via IDOR](https://hackerone.com/reports/847452) to U.S. Dept Of Defense - 8 upvotes, $0
209. [Authorization bypass -\> IDOR -\> PII Leakage](https://hackerone.com/reports/1489470) to U.S. Dept Of Defense - 8 upvotes, $0
210. [Insecure Direct Object Reference on badoo.com](https://hackerone.com/reports/126861) to Bumble - 7 upvotes, $0
211. [Insecure direct object reference vulnerability on a DoD website](https://hackerone.com/reports/184933) to U.S. Dept Of Defense - 7 upvotes, $0
212. [IDOR on ███████ [HtUS]](https://hackerone.com/reports/1627974) to U.S. Dept Of Defense - 7 upvotes, $0
213. [IDOR allows accounts to view full name of other accounts based on email through share notes feature](https://hackerone.com/reports/476958) to New Relic - 6 upvotes, $750
214. [IDOR on remoing Share](https://hackerone.com/reports/85720) to Enter - 6 upvotes, $250
215. [[c-api.city-mobil.ru] IDOR chat messages between driver and customer](https://hackerone.com/reports/850637) to Mail.ru - 6 upvotes, $150
216. [Insecure Direct Object Reference on in-scope .mil website](https://hackerone.com/reports/230026) to U.S. Dept Of Defense - 6 upvotes, $0
217. [[city-mobil.ru/taxiserv/] IDOR leads to driver account takeover](https://hackerone.com/reports/751281) to Mail.ru - 6 upvotes, $0
218. [Idor for firstpromoter service](https://hackerone.com/reports/959697) to Dropcontact - 6 upvotes, $0
219. [CRITICAL vulnerability - Insecure Direct Object Reference - Unauthorized access to `Videos` of Channel whose privacy is set to `Private`.](https://hackerone.com/reports/45960) to Vimeo - 5 upvotes, $0
220. [Insecure Direct Object References in https://vimeo.com/forums](https://hackerone.com/reports/52176) to Vimeo - 5 upvotes, $0
221. [Insecure Direct Object References that allows to read any comment (even if it should be private)](https://hackerone.com/reports/52181) to Vimeo - 5 upvotes, $0
222. [Critical - Insecure Direct Object Reference - Deleting any member of any organization remotely](https://hackerone.com/reports/120115) to Veris - 5 upvotes, $0
223. [[auto.mail.ru] IDOR на редактирование поста любого юзера.](https://hackerone.com/reports/651966) to Mail.ru - 5 upvotes, $0
224. [IDOR: Adding Contacts to Other User Groups](https://hackerone.com/reports/879960) to 8x8 - 5 upvotes, $0
225. [IDOR  on https://www.eobot.com/paypal](https://hackerone.com/reports/34728) to Eobot - 4 upvotes, $0
226. [Critical IDOR - Get Authentication Details of any Terminal/Gatekeeper](https://hackerone.com/reports/120293) to Veris - 4 upvotes, $0
227. [IDOR spam anyone's cellphone number through Cuvva app link](https://hackerone.com/reports/232562) to Cuvva - 4 upvotes, $0
228. [information disclosure via IDOR on "https://target.my.com/api/v2/coverage/segment.json?id={id}" endpoint](https://hackerone.com/reports/763258) to Mail.ru - 4 upvotes, $0
229. [Critical IDOR - Get venue data of any organization remotely](https://hackerone.com/reports/120305) to Veris - 3 upvotes, $0
230. [Critical IDOR - Can select any Parent while creating new Venue](https://hackerone.com/reports/120312) to Veris - 3 upvotes, $0
231. [Critical IDOR - Make Rule for Any Group & Any Venue remotely](https://hackerone.com/reports/120318) to Veris - 3 upvotes, $0
232. [Critical IDOR - Get Rules of any organization remotely](https://hackerone.com/reports/120314) to Veris - 3 upvotes, $0
233. [Critical IDOR - Get anyone's Terminal Data remotely](https://hackerone.com/reports/120289) to Veris - 3 upvotes, $0
234. [Critical IDOR - Set anyone's Terminal Data remotely](https://hackerone.com/reports/120291) to Veris - 3 upvotes, $0
235. [Critical IDOR - Delete any terminal/gatekeeper of any organization remotely](https://hackerone.com/reports/120288) to Veris - 3 upvotes, $0
236. [Critical IDOR - Delete any rule of any organization remotely](https://hackerone.com/reports/120126) to Veris - 3 upvotes, $0
237. [Critical IDOR - Delete any venue of any organization remotely](https://hackerone.com/reports/120123) to Veris - 3 upvotes, $0
238. [Critical IDOR - Delete any group of any organization remotely](https://hackerone.com/reports/120121) to Veris - 3 upvotes, $0
239. [Insecure Direct Object Reference on API without API key](https://hackerone.com/reports/284963) to Semrush - 3 upvotes, $0
240. [IDOR in locid parameter allowing to view others accounts Profile Locations ](https://hackerone.com/reports/966949) to Yelp - 3 upvotes, $0
241. [IDOR - User is able to download charts/dashboards from cross accounts](https://hackerone.com/reports/975749) to New Relic - 3 upvotes, $0
242. [Members Personal Information Leak Due to IDOR](https://hackerone.com/reports/847185) to U.S. Dept Of Defense - 3 upvotes, $0
243. [IDOR - Delete Users Saved Projects](https://hackerone.com/reports/800608) to U.S. Dept Of Defense - 3 upvotes, $0
244. [IDOR Lead  To VIEW & DELETE & Create api_key [HtUS]](https://hackerone.com/reports/1628012) to U.S. Dept Of Defense - 3 upvotes, $0
245. [IDOR позволяет изменить информацию о пользователе.](https://hackerone.com/reports/708182) to Mail.ru - 2 upvotes, $0
