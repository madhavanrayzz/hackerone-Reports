Top Race Condition reports from HackerOne:

1. [Race Condition allows to redeem multiple times gift cards which leads to free "money"](https://hackerone.com/reports/759247) to Reverb.com - 296 upvotes, $0
2. [Race condition in performing retest allows duplicated payments](https://hackerone.com/reports/429026) to HackerOne - 232 upvotes, $0
3. [Client-Side Race Condition using Marketo, allows sending user to data-protocol in Safari when form without onSuccess is submitted on www.hackerone.com](https://hackerone.com/reports/381356) to HackerOne - 152 upvotes, $0
4. [Race Condition leads to undeletable group member](https://hackerone.com/reports/604534) to HackerOne - 145 upvotes, $0
5. [Race condition in activating email resulting in infinite amount of diamonds received](https://hackerone.com/reports/509629) to InnoGames - 137 upvotes, $2000
6. [Bypassing HackerOne 2FA due to race condition](https://hackerone.com/reports/2598548) to HackerOne - 124 upvotes, $0
7. [Race Conditions in Popular reports feature.](https://hackerone.com/reports/146845) to HackerOne - 119 upvotes, $0
8. [Race Condition when following a user](https://hackerone.com/reports/927384) to Staging.every.org - 107 upvotes, $0
9. [Race Condition : Exploiting the loyalty claim https://xxx.vendhq.com/loyalty/claim/email/xxxxx url and gain x amount of loyalty bonus/cash](https://hackerone.com/reports/331940) to Vend VDP - 93 upvotes, $0
10. [Race Condition Enables Bypassing Verification Check](https://hackerone.com/reports/2110030) to Tools for Humanity - 90 upvotes, $3000
11. [Race Condition in Flag Submission](https://hackerone.com/reports/454949) to HackerOne - 89 upvotes, $0
12. [Race condition on add 1 free domain](https://hackerone.com/reports/2616045) to Automattic - 85 upvotes, $0
13. [Race condition leads to duplicate payouts](https://hackerone.com/reports/220445) to HackerOne - 72 upvotes, $0
14. [Race condition in joining CTF group](https://hackerone.com/reports/1540969) to HackerOne - 70 upvotes, $500
15. [Race Condition of Transfer data Credits to Organization Leads to Add Extra free Data Credits to the Organization](https://hackerone.com/reports/974892) to Helium - 69 upvotes, $250
16. [Exceed the maximum number of subscribers using Race Condition ](https://hackerone.com/reports/3221185) to SingleStore - 65 upvotes, $0
17. [Email Verification Bypass via Race Condition](https://hackerone.com/reports/3020733) to Malwarebytes - 62 upvotes, $0
18. [Exceeding the limit of Workspaces via Race Condition](https://hackerone.com/reports/3226838) to SingleStore - 56 upvotes, $0
19. [Race condition in faucet when using starport](https://hackerone.com/reports/1438052) to Cosmos - 55 upvotes, $5000
20. [Race Condition on "Get free Badoo Premium" which allows to get more days of free premium for Free. ](https://hackerone.com/reports/1037430) to Bumble - 55 upvotes, $0
21. [Race Condition in Folder Creation Allows Bypassing Folder Limit](https://hackerone.com/reports/3104355) to Dust - 52 upvotes, $0
22. [Race condition in claiming program credentials ](https://hackerone.com/reports/488985) to HackerOne - 51 upvotes, $0
23. [Race Conditions in OAuth 2 API implementations](https://hackerone.com/reports/55140) to Internet Bug Bounty - 48 upvotes, $0
24. [Race condition in User comments  Likes](https://hackerone.com/reports/1409913) to Eternal - 44 upvotes, $0
25. [Race condition leads to add more than 5 email at Data breaches monitor system at https://stage.firefoxmonitor.nonprod.cloudops.mozgcp.net](https://hackerone.com/reports/1913309) to Mozilla - 44 upvotes, $0
26. [Race condition while removing the love react in community files.](https://hackerone.com/reports/996141) to Figma - 41 upvotes, $150
27. [Race Condition in Redeeming Coupons](https://hackerone.com/reports/157996) to Instacart - 40 upvotes, $0
28. [Race condition in up voting and down voting](https://hackerone.com/reports/183837) to Urban Dictionary - 40 upvotes, $0
29. [Race conditions can be used to bypass invitation limit](https://hackerone.com/reports/115007) to Keybase - 39 upvotes, $0
30. [Race Condition on Create API Function](https://hackerone.com/reports/2682392) to Enjin - 39 upvotes, $0
31. [MozillaVPN: Elevation of Privilege via a Race Condition Vulnerability](https://hackerone.com/reports/2261577) to Mozilla - 38 upvotes, $0
32. [Race condition at create new Location](https://hackerone.com/reports/413759) to Shopify - 34 upvotes, $500
33. [Not a Vuln: Race Condition Allows Creation of Multiple Organizations with the Same Name](https://hackerone.com/reports/3248712) to WakaTime - 34 upvotes, $0
34. [Race condition leads to Inflation of coins when bought via Google Play Store at endpoint https://oauth.reddit.com/api/v2/gold/android/verify_purchase ](https://hackerone.com/reports/801743) to Reddit - 33 upvotes, $0
35. [JSBeautifier BApp: Race condition leads to memory disclosure](https://hackerone.com/reports/187134) to PortSwigger Web Security - 32 upvotes, $0
36. [Race condition via project team member invitation system.](https://hackerone.com/reports/1108291) to Enjin - 32 upvotes, $0
37. [Race condition на market.games.mail.ru](https://hackerone.com/reports/317557) to Mail.ru - 31 upvotes, $1000
38. [Race condition in endpoint POST fetlife.com/users/invitation, allow attacker to generate unlimited invites](https://hackerone.com/reports/1460373) to FetLife - 28 upvotes, $0
39. [Race Condition in account survey](https://hackerone.com/reports/165570) to Slack - 27 upvotes, $0
40. [CVE-2023-32001: fopen race condition](https://hackerone.com/reports/2039870) to curl - 26 upvotes, $0
41. [Race condition on action: Invite members to a team](https://hackerone.com/reports/1285538) to Omise - 25 upvotes, $0
42. [[api.krisp.ai] Race condition on /v2/seats endpoint allows bypassing the original seat limit](https://hackerone.com/reports/1418419) to Krisp - 25 upvotes, $0
43. [Register multiple users using one invitation (race condition)](https://hackerone.com/reports/148609) to Keybase - 23 upvotes, $0
44. [TOCTOU Race Condition in HTTP/2 Connection Reuse Leads to Certificate Validation Bypass](https://hackerone.com/reports/3335085) to curl - 23 upvotes, $0
45. [Race condition on https://judge.me/people](https://hackerone.com/reports/1566017) to Judge.me  - 22 upvotes, $250
46. [Race condition in GitLab import, giving access to other people their imports due to filename collision](https://hackerone.com/reports/214028) to GitLab - 22 upvotes, $0
47. [[curl] CVE-2023-32001: fopen race condition](https://hackerone.com/reports/2078571) to Internet Bug Bounty - 21 upvotes, $2480
48. [Race condition vulnerability on "This Rocks" button.](https://hackerone.com/reports/474021) to Rockstar Games - 21 upvotes, $0
49. [Race condition (TOCTOU) in NordVPN can result in local privilege escalation](https://hackerone.com/reports/768110) to Nord Security - 18 upvotes, $0
50. [Race Condition allows to get more free trials and get more than 100 languages and strings for free](https://hackerone.com/reports/1087188) to Weblate - 18 upvotes, $0
51. [Race condition on the Federalist API endpoints can lead to the Denial of Service attack](https://hackerone.com/reports/249319) to GSA Bounty - 17 upvotes, $0
52. [Race condition on global `gss_context` during SOCKS5 GSS-API negotiation in libcurl](https://hackerone.com/reports/3356088) to curl - 17 upvotes, $0
53. [race condition in adding team members](https://hackerone.com/reports/176127) to Shopify - 16 upvotes, $0
54. [Race Condition in Definition Votes](https://hackerone.com/reports/152717) to Urban Dictionary - 15 upvotes, $0
55. [Race condition при покупке подарков на games.mail.ru](https://hackerone.com/reports/685432) to Mail.ru - 15 upvotes, $0
56. [The endpoint /api/internal/graphql/requestAuthEmail on Khanacademy.or is vulnerable to Race Condition Attack.](https://hackerone.com/reports/1293377) to Khan Academy - 15 upvotes, $0
57. [Issue in the implementation of captcha and race condition](https://hackerone.com/reports/67562) to VK.com - 14 upvotes, $0
58. [Race condition in Flash workers may cause an exploitabl​e double free](https://hackerone.com/reports/37240) to Internet Bug Bounty - 14 upvotes, $0
59. [Race Condition Vulnerability On Pornhubpremium.com](https://hackerone.com/reports/183624) to Pornhub - 13 upvotes, $520
60. [Bypass subdomain limits using race condition](https://hackerone.com/reports/395351) to Chaturbate - 13 upvotes, $100
61. [Race Conditions Exist When Accepting Invitations](https://hackerone.com/reports/119354) to HackerOne - 13 upvotes, $0
62. [Race condition allows to send multiple times feedback for the hacker](https://hackerone.com/reports/1132171) to HackerOne - 13 upvotes, $0
63. [Race Condition in Article "Helpful" Indicator](https://hackerone.com/reports/109485) to Zendesk - 12 upvotes, $0
64. [Race condition на покупке призов за баллы](https://hackerone.com/reports/700833) to Mail.ru - 12 upvotes, $0
65. [Race Condition in Oauth 2.0 flow can lead to malicious applications create multiple valid sessions](https://hackerone.com/reports/699112) to Razer - 8 upvotes, $250
66. [Acronis True Image Local Privilege Escalation Due To Race Condition In Application Verification ](https://hackerone.com/reports/1251464) to Acronis - 8 upvotes, $0
67. [ CVE-2023-28320 - siglongjmp race condition](https://hackerone.com/reports/1990421) to Internet Bug Bounty - 7 upvotes, $480
68. [Race condition allowing user to review app multiple times](https://hackerone.com/reports/106360) to Coinbase - 7 upvotes, $0
69. [Race condition on my.stripo.email at /cabinet/stripeapi/v1/projects/298427/emails/folders uri](https://hackerone.com/reports/994051) to Stripo Inc - 6 upvotes, $0
70. [Race Condition Vulnerability when creating profiles](https://hackerone.com/reports/1428690) to Showmax - 6 upvotes, $0
71. [CVE-2023-28320: siglongjmp race condition](https://hackerone.com/reports/1929597) to curl - 6 upvotes, $0
72. [Race condition when redeeming coupon codes](https://hackerone.com/reports/59179) to Dropbox - 5 upvotes, $216
73. [Race condition in workers may cause an exploitable double free by abusing bytearray.compress()  ](https://hackerone.com/reports/47227) to Internet Bug Bounty - 5 upvotes, $0
74. [Adobe Flash Player Race Condition Vulnerability](https://hackerone.com/reports/119657) to Internet Bug Bounty - 4 upvotes, $2000
75. [Race condition with CURL_LOCK_DATA_CONNECT can cause connections to be used at the same time](https://hackerone.com/reports/724134) to curl - 1 upvotes, $0
76. [Data race conditions reported by helgrind when performing parallel DNS queries in libcurl](https://hackerone.com/reports/1019457) to curl - 0 upvotes, $0
